/* FromYourNetwork app, concept voor app.fromyournetwork.com.
   Alles wat de gebruiker invoert blijft in deze browser (localStorage). Er gaat niets naar een server.
   De echte app vervangt de opslag door de API; de schermen, de stappen en de woorden blijven.
   Harde grenzen uit CLAUDE.md gelden hier ook: geen inhoud van mail, niets versturen, "waarschijnlijk" bij afleidingen. */
(function () {
'use strict';

/* ------------------------------------------------------------------ instellingen */
const BRAND = 'FromYourNetwork';
const SITE = 'https://fromyournetwork.com';
const MCP_URL = 'https://mcp.fromyournetwork.com';
const APP_HOST = 'app.fromyournetwork.com';
const TRIAL_DAYS = 7;
/* partnerprogramma; gelijk aan site/config.py PARTNER */
const PARTNER = { agencyPct: 30, affiliatePct: 25, affiliateMonths: 12, windowDays: 90, payoutMin: 50, refundDays: 30, clientTrialDays: 14 };
const trialDays = () => (S && S.referral ? PARTNER.clientTrialDays : TRIAL_DAYS);
const PRICE_EXTRA = 15;
const MONTHLY_EXTRA = 20; // per maand betalen en opzeggen: zoveel euro per maand meer (gelijk aan site/config.py)
const PLANS = {
  free:    { name: 'Free',    price: 0,   users: 1, recog: 10,  perMail: 1, rhythms: ['1× per week'] },
  starter: { name: 'Starter', price: 29,  users: 1, recog: 50,  perMail: 3, rhythms: ['2× per week', '1× per week'] },
  growth:  { name: 'Growth',  price: 119, users: 3, recog: 300, perMail: 5, rhythms: ['Elke werkdag', '2× per week', '1× per week'] },
  pro:     { name: 'Pro',     price: 179, users: 5, recog: 750, perMail: 5, rhythms: ['Elke werkdag', '2× per week', '1× per week'] },
};
const STEPS = [
  { id: 'account', t: 'Account', d: '1 minuut' },
  { id: 'plan', t: 'Kies je start', d: '10 seconden' },
  { id: 'site', t: 'Website', d: '2 minuten' },
  { id: 'linkedin', t: 'LinkedIn', d: '2 minuten' },
  { id: 'meta', t: 'Instagram en Facebook', d: '1 minuut' },
  { id: 'ai', t: 'Claude of ChatGPT', d: '1 minuut' },
  { id: 'klanten', t: 'Klanten', d: '2 minuten' },
  { id: 'icp', t: 'Ideale klant', d: '2 minuten' },
  { id: 'team', t: "Collega's", d: '1 minuut' },
];
/* De bronnen, in de volgorde van de start. max telt op tot 100: de sterkte van je bronnen. */
const SOURCES = [
  { id: 'site', t: 'Website', icon: 'globe', max: 25, first: true, why: 'Welke bedrijven je site bezoeken' },
  { id: 'linkedin', t: 'LinkedIn', icon: 'users', max: 25, why: 'Wie je kent, en sinds wanneer' },
  { id: 'meta', t: 'Instagram en Facebook', short: 'Instagram', icon: 'image', max: 10, why: 'Wie je volgt, een bericht stuurt of reageert' },
  { id: 'ai', t: 'Claude of ChatGPT', icon: 'spark', max: 5, why: 'Je CRM via je AI, zonder exporteren' },
  { id: 'klanten', t: 'Klanten', icon: 'crm', max: 15, why: 'Oud-klanten en open offertes' },
  { id: 'icp', t: 'Ideale klant', icon: 'target', max: 10, why: 'Welke bedrijven bij je passen' },
  { id: 'team', t: "Collega's", icon: 'net', max: 10, why: 'Hun netwerk erbij' },
];
const FREE_MAIL = /@(gmail|googlemail|hotmail|outlook|live|icloud|me|yahoo|ziggo|kpnmail|home|planet|xs4all|telfort|chello|hetnet)\./i;

/* ------------------------------------------------------------------ opslag */
const KEY = 'fyn-app-concept-v1';
function blank() {
  return { v: 1, account: null, plan: null, trialStart: null, finished: false, parked: false, done: {}, skipped: {},
    li: [], liRequested: null, cust: null, crm: '', custVia: '', custAiSent: false, aiLinked: false, meta: { connected: false, at: null, followers: null },
    referral: null, partner: null, agencyAccess: [], accessLog: [], site: { mode: null, who: null, tool: '', toolOther: '', method: 'zelf', platform: null, verified: false, verifiedAt: null, builder: '', builderSent: false }, icp: { text: '', crit: [], critFrom: '' }, dream: [],
    mail: { rhythm: null, time: '08:00', paused: false }, team: [], ai: null, fb: {}, sample: false };
}
function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const o = JSON.parse(raw);
      if (o && o.v === 1) {
        const b = blank(); const d = o.done || {};
        if ('network' in d) { d.linkedin = !!(o.li && o.li.length); d.klanten = !!o.cust; delete d.network; }
        if (d.mail) { d.team = true; delete d.mail; }
        o.done = d; o.site = Object.assign(b.site, o.site || {}); o.icp = Object.assign(b.icp, o.icp || {}); o.skipped = o.skipped || {}; o.meta = Object.assign(b.meta, o.meta || {});
        if (o.icp.crit.length && !o.icp.critFrom) o.icp.critFrom = o.icp.text.trim();
        if (!o.site.who && o.site.mode) o.site.who = o.site.mode === 'own' ? 'own' : 'zelf';
        if (o.ai === 'later') o.ai = null;
        return Object.assign(b, o);
      }
    }
  } catch (e) { /* geen opslag beschikbaar: werk in het geheugen */ }
  return blank();
}
let storeOk = true;
function save() {
  try { S.drafts = { dream: U.dreamDraft || '', tm: U.tm || null }; } catch (e) { /* U bestaat nog niet */ }
  try { localStorage.setItem(KEY, JSON.stringify(S)); storeOk = true; }
  catch (e) { storeOk = false; }
}
let S = load();
const U = { sel: 'np', confirm: null, open: {}, q: '', custDraft: null, err: {}, pendingPlan: null, tm: (S.drafts && S.drafts.tm) || null, dreamDraft: (S.drafts && S.drafts.dream) || '', planPick: null, ret: null, forceSignup: false, design: false };

/* ------------------------------------------------------------------ hulp */
const $ = (s, el) => (el || document).querySelector(s);
const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nf = n => Number(n).toLocaleString('nl-NL');
const euro = n => '€ ' + nf(n);
const todayIso = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const MONTHS = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
function fmtDate(iso) { if (!iso) return ''; const [y, m, d] = iso.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; }
function initials(name) { return (name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0].toUpperCase()).join('') || '?'; }
function firstName(name) { return (name || '').trim().split(/\s+/)[0] || ''; }
function greet() { const h = new Date().getHours(); return h < 12 ? 'Goedemorgen' : h < 18 ? 'Goedemiddag' : 'Goedenavond'; }
function plural(n, one, many) { return `${nf(n)} ${n === 1 ? one : many}`; }
function domainOf(s) { return (s || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[/?#]/)[0]; }
function slugOf(s) { return domainOf(s).replace(/\.[a-z]+$/, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'jouwsite'; }

const I = {
  check: '<path d="M5 12.5l4.2 4.2L19 7"/>',
  info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8v.01"/>',
  spark: '<path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z"/>',
  home: '<path d="M4 11.5L12 5l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5h-5v5H5a1 1 0 0 1-1-1z"/>',
  net: '<circle cx="6" cy="7" r="2.5"/><circle cx="18" cy="7" r="2.5"/><circle cx="12" cy="17" r="2.5"/><path d="M8.2 8.3l2.6 6.4M15.8 8.3l-2.6 6.4M8.5 7h7"/>',
  plug: '<path d="M9 3.5v4M15 3.5v4M7 7.5h10v3a5 5 0 0 1-10 0z"/><path d="M12 15.5v5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4L18 18M6 18l1.6-1.6M16.4 7.6L18 6"/>',
  phone: '<path d="M5.2 4.5h3.1l1.6 4-2 1.3a10.5 10.5 0 0 0 6.3 6.3l1.3-2 4 1.6v3.1a1.5 1.5 0 0 1-1.6 1.5A15.6 15.6 0 0 1 3.7 6.1a1.5 1.5 0 0 1 1.5-1.6z"/>',
  mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2.8"/><path d="M4.2 7.5l7.8 5.8 7.8-5.8"/>',
  users: '<circle cx="9.5" cy="8" r="3.5"/><path d="M3.5 20v-1.4a3.6 3.6 0 0 1 3.6-3.6h4.8a3.6 3.6 0 0 1 3.6 3.6V20"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M20.5 20v-1.4a3.6 3.6 0 0 0-2.6-3.45"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/>',
  up: '<path d="M12 16V5"/><path d="M7 10l5-5 5 5"/><path d="M5 19.5h14"/>',
  chev: '<path d="M9.5 6l6 6-6 6"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  lock: '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  globe: '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.4 2.6 3.6 5.4 3.6 8.5s-1.2 5.9-3.6 8.5c-2.4-2.6-3.6-5.4-3.6-8.5s1.2-5.9 3.6-8.5z"/>',
  crm: '<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><path d="M3.5 9h17"/><circle cx="8.5" cy="14" r="2"/><path d="M13 13h4.5M13 16h3"/>',
  target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1"/>',
  code: '<path d="M8.5 7.5L4 12l4.5 4.5M15.5 7.5L20 12l-4.5 4.5"/>',
  tag: '<path d="M3.5 12.2V4.5a1 1 0 0 1 1-1h7.7l8.3 8.3a1 1 0 0 1 0 1.4l-6.9 6.9a1 1 0 0 1-1.4 0z"/><circle cx="8" cy="8" r="1.4"/>',
  shield: '<path d="M12 3.5l7 2.6v5.4c0 4.3-3 7.7-7 9-4-1.3-7-4.7-7-9V6.1z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
  image: '<rect x="4" y="4" width="16" height="16" rx="4.6"/><circle cx="12" cy="12" r="3.6"/><path d="M16.9 7.1v.01"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3.2 2"/>',
};
const ic = (n, c = 'currentColor', w = 1.9) => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${I[n]}</svg>`;
const LOGO = '<svg width="28" height="28" viewBox="0 0 34 34" aria-hidden="true" focusable="false"><defs><linearGradient id="lg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8FB4FF"/><stop offset="1" stop-color="#6C5CE7"/></linearGradient><linearGradient id="lg2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#C9B8FF"/><stop offset="1" stop-color="#5B4BDB"/></linearGradient></defs><circle cx="13" cy="19" r="10" fill="url(#lg1)"/><circle cx="22" cy="12" r="8" fill="url(#lg2)" opacity=".92"/><circle cx="25.5" cy="25" r="4" fill="#3E7BFA" opacity=".85"/></svg>';
const WORD = BRAND === 'FromYourNetwork' ? 'From<b>Your</b>Network' : esc(BRAND);

let toastT = null;
function toast(t) {
  const e = $('#toast'); if (!e) return;
  e.textContent = t; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { e.hidden = true; }, 2600);
}
function copyText(id) {
  const el = document.getElementById(id); if (!el) return;
  const pick = () => { const r = document.createRange(); r.selectNodeContents(el); const s = getSelection(); s.removeAllRanges(); s.addRange(r); toast('Geselecteerd. Kopieer met Ctrl+C of Cmd+C'); };
  try { navigator.clipboard.writeText(el.textContent).then(() => toast('Gekopieerd'), pick); } catch (e) { pick(); }
}

/* ------------------------------------------------------------------ bestanden lezen (in de browser) */
function parseCSV(text) {
  text = text.replace(/^\uFEFF/, '');
  const first = (text.split(/\r?\n/).find(l => l.trim()) || '');
  const count = ch => first.split(ch).length - 1;
  const d = count(';') > count(',') ? ';' : (count('\t') > count(',') ? '\t' : ',');
  const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; continue; }
    if (c === '"') { q = true; continue; }
    if (c === d) { row.push(f); f = ''; continue; }
    if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(f); rows.push(row); row = []; f = ''; continue; }
    f += c;
  }
  if (f !== '' || row.length) { row.push(f); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim() !== ''));
}

/* Een zip lezen zonder bibliotheek: de centrale map doorlopen en het ene bestand uitpakken. */
async function zipEntry(buf, test) {
  const dv = new DataView(buf); let eocd = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) { if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; } }
  if (eocd < 0) throw new Error('Dit is geen geldige zip.');
  let p = dv.getUint32(eocd + 16, true); const count = dv.getUint16(eocd + 10, true);
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) break;
    const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true);
    const nlen = dv.getUint16(p + 28, true), elen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true), lho = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(buf, p + 46, nlen));
    if (test(name)) {
      const start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
      const data = new Uint8Array(buf, start, csize);
      if (method === 0) return new TextDecoder().decode(data);
      if (method === 8 && typeof DecompressionStream !== 'undefined') {
        const out = await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer();
        return new TextDecoder().decode(out);
      }
      throw new Error('Deze browser kan de zip niet uitpakken. Pak hem zelf uit en kies Connections.csv.');
    }
    p += 46 + nlen + elen + clen;
  }
  return null;
}

const MON = { jan: 1, feb: 2, mar: 3, mrt: 3, apr: 4, may: 5, mei: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, okt: 10, nov: 11, dec: 12 };
function liDate(s) {
  s = (s || '').trim(); let m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return s.slice(0, 10);
  m = s.match(/^(\d{1,2})[\s-]([A-Za-z]{3})[a-z]*\.?[\s-](\d{2,4})$/);
  if (m) { const mo = MON[m[2].toLowerCase()]; let y = +m[3]; if (y < 100) y += 2000; if (mo) return `${y}-${String(mo).padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
  const t = Date.parse(s); return isNaN(t) ? '' : new Date(t).toISOString().slice(0, 10);
}
function parseLinkedIn(text) {
  const rows = parseCSV(text);
  const hi = rows.findIndex(r => r.some(x => /^(first name|voornaam)$/i.test(x.trim())));
  if (hi < 0) throw new Error('Dit lijkt geen LinkedIn-export. Kies Connections.csv, of de zip die LinkedIn je mailde.');
  const h = rows[hi].map(x => x.trim().toLowerCase());
  const ix = (...names) => h.findIndex(x => names.includes(x));
  const fi = ix('first name', 'voornaam'), la = ix('last name', 'achternaam'), ur = ix('url'), co = ix('company', 'bedrijf'), po = ix('position', 'functie'), on = ix('connected on', 'verbonden op', 'connectie sinds');
  const out = [];
  for (const r of rows.slice(hi + 1)) {
    const first = (r[fi] || '').trim(), last = (r[la] || '').trim(); if (!first && !last) continue;
    const url = ur >= 0 ? (r[ur] || '').trim().split('?')[0].replace(/\/$/, '') : '';
    // Bewust geen mailadres: dat hebben we voor de verbanden niet nodig.
    out.push([(url || (first + ' ' + last)).toLowerCase(), first, last, co >= 0 ? (r[co] || '').trim() : '', po >= 0 ? (r[po] || '').trim() : '', on >= 0 ? liDate(r[on]) : '']);
  }
  if (!out.length) throw new Error('In dit bestand staan geen connecties.');
  return out;
}

/* ------------------------------------------------------------------ verbanden */
function normCo(s) {
  return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/&/g, ' en ')
    .replace(/[^a-z0-9 ]+/g, ' ').replace(/\b(b ?v|n ?v|holding|groep|group|vof|v o f|gmbh|ltd|inc|the)\b/g, ' ').replace(/\s+/g, ' ').trim();
}
const snaps = () => S.li.slice().sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
const latest = () => { const s = snaps(); return s[s.length - 1] || null; };
function companies(snap) {
  const m = new Map();
  if (!snap) return m;
  for (const r of snap.rows) {
    const k = normCo(r[3]); if (!k) continue;
    if (!m.has(k)) m.set(k, { name: r[3], people: [] });
    m.get(k).people.push(r);
  }
  return m;
}
function findCo(map, name) {
  const k = normCo(name); if (!k) return null;
  if (map.has(k)) return Object.assign({ exact: true }, map.get(k));
  if (k.length < 4) return null;
  for (const [kk, v] of map) { if (kk.length >= 4 && (kk.includes(k) || k.includes(kk))) return Object.assign({ exact: false }, v); }
  return null;
}
function changes() {
  const s = snaps(); if (s.length < 2) return [];
  const prev = new Map(s[s.length - 2].rows.map(r => [r[0], r])), cur = s[s.length - 1];
  const out = [];
  const seen = new Set();
  for (const r of cur.rows) {
    if (seen.has(r[0])) continue; seen.add(r[0]);
    const p = prev.get(r[0]); if (!p) continue;
    if (normCo(p[3]) && normCo(r[3]) && normCo(p[3]) !== normCo(r[3])) out.push({ person: r, from: p[3], fromPos: p[4], since: cur.date, was: s[s.length - 2].date });
  }
  return out;
}
function jobHistory(key) {
  const out = [];
  for (const s of snaps()) { const r = s.rows.find(x => x[0] === key); if (r && (!out.length || normCo(out[out.length - 1].co) !== normCo(r[3]))) out.push({ co: r[3], pos: r[4], date: s.date }); }
  return out;
}
function custClass(s) {
  s = (s || '').toLowerCase();
  if (/\b(oud|ex|former|churn|vorige|beeindigd|beëindigd|gestopt)\b|oud-klant|oudklant/.test(s)) return 'oud';
  if (/offerte|quote|proposal|deal|opportunit|voorstel/.test(s)) return 'offerte';
  if (/prospect|lead|kans/.test(s)) return 'prospect';
  if (/klant|customer|client|actief|active/.test(s)) return 'klant';
  return 'overig';
}
const CLS = { klant: 'klanten', oud: 'oud-klanten', offerte: 'offertes', prospect: 'prospects', overig: 'overig' };

function insights() {
  const snap = latest(); if (!snap) return [];
  const map = companies(snap); const out = [];
  const ch = changes();
  for (const c of ch) {
    const dream = S.dream.some(d => { const f = findCo(new Map([[normCo(c.person[3]), { name: c.person[3], people: [] }]]), d); return !!f; });
    out.push({ kind: 'rec', score: dream ? 100 : 80, co: c.person[3], c });
  }
  for (const d of (S.dream.length ? S.dream : S.sample && S.sampleDream ? S.sampleDream : [])) { const f = findCo(map, d); if (f) out.push({ kind: 'dream', score: 70 + Math.min(f.people.length, 9), co: f.name, dream: d, f }); }
  if (S.cust) {
    for (const r of S.cust.rows) {
      if (r[3] !== 'oud' && r[3] !== 'offerte') continue;
      const f = findCo(map, r[0]); if (!f) continue;
      out.push({ kind: r[3], score: r[3] === 'oud' ? 60 : 55, co: f.name, f, r });
    }
  }
  const seen = new Set();
  return out.sort((a, b) => b.score - a.score).filter(x => { const k = x.kind + '|' + normCo(x.co); if (seen.has(k)) return false; seen.add(k); return true; });
}

/* ------------------------------------------------------------------ voorbeeldgegevens */
function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function sampleData() {
  const R = rng(20261011);
  const FN = ['Anne', 'Bram', 'Daan', 'Emma', 'Femke', 'Gijs', 'Hanna', 'Iris', 'Jeroen', 'Kim', 'Lars', 'Maaike', 'Niels', 'Olga', 'Pim', 'Roos', 'Sem', 'Tessa', 'Ruben', 'Wouter', 'Yara', 'Joost', 'Marloes', 'Thijs', 'Esther', 'Koen', 'Lotte', 'Bas', 'Sanne', 'Rik'];
  const LN = ['de Vries', 'van Dijk', 'Bakker', 'Visser', 'Smit', 'Meijer', 'de Boer', 'Mulder', 'de Groot', 'Bos', 'Vos', 'Peters', 'Hendriks', 'Dekker', 'Brouwer', 'de Wit', 'Dijkstra', 'Kok', 'Jacobs', 'van der Meer', 'Hoekstra', 'Postma', 'Kuipers', 'Veenstra', 'Wiersma'];
  const CO = ['Northpeak B.V.', 'Vela Energy', 'Corvus Health', 'Arden Logistiek', 'Hesselink Bouw', 'Duinkerk Zorg', 'Zuiderhaven Media', 'Meridiaan Software', 'Ostrand Logistics', 'Hoogland Bouw', 'Kanaalzicht Advies', 'Wadkust Techniek', 'Eemsmond Energie', 'Lauwers Installatie', 'Noorderpoort Opleidingen', 'Reitdiep Retail', 'Hunze Software', 'Marne Accountants', 'Fivel Food', 'Ommeland Mobiliteit', 'Dollard Data', 'Zernike Labs', 'Westerkwartier Groen', 'Hondsrug Hout', 'Stadspark Events'];
  const POS = ['Directeur', 'Marketingmanager', 'Commercieel directeur', 'Accountmanager', 'Office manager', 'Inkoper', 'Operationeel manager', 'Financieel manager', 'Projectleider', 'Eigenaar', 'HR-adviseur', 'Salesmanager'];
  const pick = a => a[Math.floor(R() * a.length)];
  const rows = []; const used = new Set(['peter jansen', 'sanne dijkstra', 'lisa de haan', 'eva bakker', 'mark visser', 'ilse de boer', 'joris kramer']);
  for (let y = 2014; y <= 2026; y++) {
    const n = Math.round(4 + (y - 2014) * 1.7 + R() * 5);
    for (let i = 0; i < n; i++) {
      let f, l, k; do { f = pick(FN); l = pick(LN); k = (f + ' ' + l).toLowerCase(); } while (used.has(k));
      used.add(k);
      const mo = 1 + Math.floor(R() * (y === 2026 ? 9 : 12)), d = 1 + Math.floor(R() * 27);
      rows.push(['https://www.linkedin.com/in/' + k.replace(/\s+/g, '-'), f, l, R() < .12 ? '' : pick(CO), pick(POS), `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`]);
    }
  }
  const fixed = [
    ['Peter', 'Jansen', 'Ostrand Logistics', 'Accountmanager', 'Northpeak B.V.', 'Marketingmanager', '2019-03-12'],
    ['Sanne', 'Dijkstra', 'Hoogland Bouw', 'Marketingcoördinator', 'Meridiaan Software', 'Marketingdirecteur', '2019-06-04'],
    ['Lisa', 'de Haan', 'Vela Energy', 'Directeur', 'Vela Energy', 'Directeur', '2021-09-20'],
    ['Eva', 'Bakker', 'Corvus Health', 'Inkoper', 'Corvus Health', 'Inkoper', '2022-02-14'],
    ['Mark', 'Visser', 'Arden Logistiek', 'Directeur', 'Arden Logistiek', 'Directeur', '2018-11-02'],
    ['Ilse', 'de Boer', 'Ostrand Logistics', 'Financieel manager', 'Ostrand Logistics', 'Financieel manager', '2021-05-17'],
    ['Joris', 'Kramer', 'Wadkust Techniek', 'Salesmanager', 'Hesselink Bouw', 'Commercieel directeur', '2017-08-30'],
  ];
  const newRows = rows.map(r => r.slice());
  for (const [f, l, oc, op, nc, np, d] of fixed) {
    const k = ('https://www.linkedin.com/in/' + (f + ' ' + l).toLowerCase().replace(/\s+/g, '-'));
    rows.push([k, f, l, oc, op, d]); newRows.push([k, f, l, nc, np, d]);
  }
  const july = { id: 's1', date: '2026-07-11', file: 'Connections.csv (voorbeeld, juli)', rows };
  const now = { id: 's2', date: todayIso(), file: 'Connections.csv (voorbeeld, nu)', rows: newRows };
  const cust = { file: 'klanten.csv (voorbeeld)', date: todayIso(), rows: [
    ['Ostrand Logistics', 'Ilse de Boer', 'ostrand-logistics.nl', 'oud', 'Oud-klant'],
    ['Arden Logistiek', 'Mark Visser', 'ardenlogistiek.nl', 'oud', 'Oud-klant'],
    ['Corvus Health', 'Eva Bakker', 'corvushealth.nl', 'offerte', 'Offerte'],
    ['Hoogland Bouw', 'Sanne Dijkstra', 'hooglandbouw.nl', 'offerte', 'Offerte'],
    ['Kanaalzicht Advies', 'Roos Smit', 'kanaalzicht.nl', 'klant', 'Klant'],
    ['Marne Accountants', 'Bas Kok', 'marne-accountants.nl', 'klant', 'Klant'],
    ['Fivel Food', 'Femke Dekker', 'fivelfood.nl', 'klant', 'Klant'],
    ['Reitdiep Retail', 'Pim Bos', 'reitdiepretail.nl', 'prospect', 'Prospect'],
    ['Zernike Labs', 'Yara Postma', 'zernikelabs.nl', 'prospect', 'Prospect'],
    ['Lauwers Installatie', 'Koen Hoekstra', 'lauwersinstallatie.nl', 'oud', 'Oud-klant'],
  ] };
  return { snaps: [july, now], cust, dream: ['Northpeak B.V.', 'Vela Energy', 'Meridiaan Software', 'Hesselink Bouw', 'Duinkerk Zorg'],
    icp: 'Wij helpen B2B-bedrijven met online marketing. Onze ideale klanten hebben 10 tot 200 medewerkers, zitten in Noord-Nederland en willen groeien. Vooral zakelijke dienstverlening, logistiek en software, met een eigen marketingafdeling.' };
}

/* Voorbeeldkansen: zo ziet een kans eruit zodra herkenning en signalen live zijn. */
const EX = [
  { id: 'np', m: 'N', c: '#0E1330', n: 'Northpeak B.V.', t: ['Warme kans', 'p-warm'], w: 'Bekeek je prijspagina 3× · je kent er Peter Jansen',
    fit: 'Zakelijke dienstverlening, 85 werkzame personen, Groningen. Past op 4 van je 5 criteria.', fitSrc: 'KVK-basisprofiel',
    now: 'Bekeek je prijspagina 3× deze week, en plaatste op 8 oktober een vacature voor een online marketeer.', nowSrc: 'Websiteherkenning (zeker voor het bedrijf) en vacaturefeed',
    who: 'Peter Jansen, marketingmanager. Je kent hem sinds 2019, toen bij Ostrand Logistics.', whoSrc: 'LinkedIn-exports en klantenbestand · zeker',
    call: 'Bellen mag: Northpeak is een bv', mail: false, mailWhy: 'Mailen: alleen met een grond. Een mail van 3 jaar geleden is dat niet.', person: 'Peter',
    tl: [['2019', 'LinkedIn-connectie. Peter werkt dan bij <b>Ostrand Logistics</b>.'], ['2021', 'Ostrand Logistics vraagt een offerte aan. Peter is je contactpersoon.'], ['2023', 'Peter mailt je. Hij werkt inmiddels bij <b>Northpeak</b>.'], ['Nu', 'Northpeak bekijkt je prijspagina, 3× deze week.']] },
  { id: 've', m: 'V', c: '#5B4BDB', n: 'Vela Energy', t: ['Ingang in je netwerk', 'p-net'], w: 'Aanvraag op je site · Tom kent hun directeur',
    fit: 'Energieadvies, 40 werkzame personen, Friesland. Past op 5 van 5 criteria.', fitSrc: 'KVK-basisprofiel',
    now: 'Lisa de Haan vulde gisteren je contactformulier in: "Offerte Google Ads".', nowSrc: 'Formulier op je site · zeker',
    who: 'Tom (collega) kent Lisa de Haan, de directeur. Laatste contact in juni.', whoSrc: 'LinkedIn-export van Tom · Tom deelt de naam',
    call: 'Bellen mag: Vela Energy is een bv', mail: true, mailWhy: 'Mailen mag: eigen aanvraag van deze persoon.', person: 'Lisa' },
  { id: 'pn', m: 'P', c: '#2F6FEB', n: 'Provincie Noordkust', t: ['Opdracht', 'p-job'], w: 'Aanbesteding online campagnes 2027 · sluit 6 nov',
    fit: 'Opdracht voor SEA en campagnes, regio Noord-Nederland. Past op je diensten.', fitSrc: 'TenderNed, gepubliceerd 9 okt',
    now: 'De inschrijving sluit op 6 november.', nowSrc: 'TenderNed',
    who: 'Nog niemand. Check de voorwaarden voor je inschrijft.', whoSrc: 'Geen ingang gevonden in jullie netwerk',
    call: 'Inschrijven gaat via TenderNed', mail: false, mailWhy: 'Geen persoon om te benaderen.', person: null },
  { id: 'md', m: 'M', c: '#7C3AED', n: 'Meridiaan Software', t: ['Reconnect', 'p-rec'], w: 'Sanne Dijkstra, sinds 2018 in je netwerk, is hier nu marketingdirecteur',
    fit: 'Software, 45 werkzame personen, Groningen. Staat op je droomklantenlijst.', fitSrc: 'Droomklanten en KVK-basisprofiel',
    now: 'Sanne begon deze maand als marketingdirecteur.', nowSrc: 'Nieuwe LinkedIn-export, vergeleken met die van juli',
    who: 'Sanne Dijkstra. Offerte bij Hoogland Bouw in 2020, LinkedIn-connectie sinds 2019.', whoSrc: 'Klantenbestand en LinkedIn-exports · zeker',
    call: 'Bellen mag: Meridiaan Software is een bv', mail: false, mailWhy: 'Mailen: alleen met een grond. Een oude offerte bij een ander bedrijf is dat niet.', person: 'Sanne',
    tl: [['2019', 'LinkedIn-connectie. Sanne werkt dan bij <b>Hoogland Bouw</b>.'], ['2020', 'Hoogland Bouw vraagt een offerte aan, via Sanne.'], ['Nu', 'Sanne is marketingdirecteur bij <b>Meridiaan Software</b>.']] },
];

/* ------------------------------------------------------------------ voortgang
   Of een stap af is, rekenen we elke keer uit de gegevens zelf uit. Er is geen los vinkje dat kan afwijken:
   de stappenbalk, het paneel, de knop onderin en het klaar-scherm lezen allemaal stepStatus(). */
const DATA_STEPS = STEPS.slice(2);
const stepNo = id => STEPS.findIndex(x => x.id === id) + 1;
const AI_NAME = { claude: 'Claude', chatgpt: 'ChatGPT' };
const aiOn = () => S.plan !== 'free' && (S.ai === 'claude' || S.ai === 'chatgpt');
const AI_CRMS = ['hubspot', 'pipedrive', 'salesforce', 'teamleader', 'anders'];
/* je AI ververst je klanten elke werkdag, een uur voor je kansenmail */
function refreshTime() { const [h, m] = (S.mail.time || '08:00').split(':').map(Number); const t = Math.max(0, h * 60 + m - 60); return String(Math.floor(t / 60)).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); }
const custViaAi = () => aiOn() && AI_CRMS.includes(S.crm) && S.custVia === 'ai';
function toolOk() { return !!S.site.tool && (S.site.tool !== 'Iets anders' || !!S.site.toolOther.trim()); }
function stepStatus(id) {
  switch (id) {
    case 'site': if (S.site.verified || (S.site.who === 'own' && toolOk())) return 'done'; if (S.site.who === 'bouwer' && S.site.builderSent) return 'wait'; return S.site.who ? 'partial' : 'todo';
    case 'linkedin': if (realLi().length) return 'done'; return S.liRequested ? 'wait' : 'todo';
    case 'meta': return S.meta.connected || S.meta.followers ? 'done' : 'todo';
    case 'klanten': if (realCust() || S.crm === 'geen') return 'done'; if (custViaAi() && S.custAiSent) return 'wait'; return S.crm || U.custDraft ? 'partial' : 'todo';
    case 'icp': if (S.icp.crit.length && S.dream.length) return 'done'; return S.icp.crit.length || S.dream.length || S.icp.text.trim() ? 'partial' : 'todo';
    case 'team': return S.team.length ? 'done' : 'todo';
    case 'ai': if (S.plan === 'free' || S.ai === 'none') return 'done'; if (aiOn()) return S.aiLinked ? 'done' : 'partial'; return 'todo';
  }
  return 'todo';
}
const isReady = id => { const s = stepStatus(id); return s === 'done' || s === 'wait'; };
function doneCount() { return DATA_STEPS.filter(s => isReady(s.id)).length; }
function firstOpen() { const s = DATA_STEPS.find(x => !isReady(x.id) && !S.skipped[x.id]); return s ? stepNo(s.id) : STEPS.length + 1; }
function plan() { return PLANS[S.plan || 'growth']; }
function trialLeft() {
  if (S.plan !== 'growth' || !S.trialStart) return null;
  const used = Math.floor((Date.now() - new Date(S.trialStart).getTime()) / 86400000);
  return Math.max(0, trialDays() - used);
}
function trialEnd() { return S.trialStart ? fmtDate(new Date(new Date(S.trialStart).getTime() + trialDays() * 86400000).toISOString().slice(0, 10)) : ''; }
function startTrialIfReady() {
  if (S.plan === 'growth' && !S.trialStart && (realLi().length || realCust() || S.site.verified || S.meta.connected)) { S.trialStart = new Date().toISOString(); toast(`Je ${trialDays()} dagen Growth zijn begonnen`); }
}
function ensureRhythm() { const r = plan().rhythms; if (!r.includes(S.mail.rhythm)) S.mail.rhythm = r[0]; }
function setPlan(v) {
  if (!PLANS[v]) return;
  if (S.plan !== v) {
    if (v === 'free') { S.trialStart = null; S.team.forEach(m => { if (m.role === 'Gebruiker') { m.prevRole = 'Gebruiker'; m.role = 'Netwerklid'; } }); }
    else S.team.forEach(m => { if (m.prevRole) { m.role = m.prevRole; delete m.prevRole; } });
  }
  S.plan = v; S.done.plan = true; startTrialIfReady(); ensureRhythm();
}
function srcScore(id) {
  switch (id) {
    case 'site': return S.site.verified ? 25 : stepStatus('site') === 'done' ? 18 : S.site.builderSent ? 10 : S.site.who ? 5 : 0;
    case 'meta': return S.meta.connected ? (S.meta.followers ? 10 : 8) : S.meta.followers ? 5 : 0;
    case 'linkedin': return realLi().length ? 25 : S.liRequested ? 8 : 0;
    case 'klanten': return realCust() ? 15 : custViaAi() && S.custAiSent ? 12 : 0;
    case 'icp': return (S.icp.crit.length ? 5 : 0) + (S.dream.length >= 3 ? 5 : S.dream.length ? 2 : 0);
    case 'team': return S.team.length ? 10 : 0;
    case 'ai': return aiOn() && S.aiLinked ? 5 : 0;
  }
  return 0;
}
function strength() { return SOURCES.reduce((a, s) => a + srcScore(s.id), 0); }
function strengthLabel(n) { return n >= 85 ? 'Sterk' : n >= 60 ? 'Goed' : n >= 30 ? 'Redelijk' : 'Net begonnen'; }
function nextOpen() { const n = firstOpen(); return n > STEPS.length ? 'klaar' : 'start-' + n; }
function curStep() { const h = location.hash.slice(1); const m = /^start-(\d+)$/.exec(h); const n = m ? +m[1] : 0; return n >= 3 && n <= STEPS.length ? n : 0; }
const NUM = ['nul', 'een', 'twee', 'drie', 'vier', 'vijf', 'zes', 'zeven', 'acht', 'negen', 'tien'];
/* een tip per bron die nog meer kan opleveren; een bewust "nee" telt als antwoord */
function tipFor(id) {
  const d = S.dream.length;
  switch (id) {
    case 'site': return S.site.who === 'bouwer' && S.site.builderSent ? 'Controleer of je webbouwer het script plaatste' : S.site.who === 'own' && toolOk() ? 'Zet ook ons script erbij, voor meer herkenningen' : S.site.who ? 'Maak je website af' : 'Zet het script op je site';
    case 'linkedin': return S.liRequested ? 'Upload je zip zodra LinkedIn mailt' : 'Voeg je LinkedIn-netwerk toe';
    case 'meta': return S.meta.connected && !S.meta.followers ? 'Voeg je Instagram-volgers toe' : 'Koppel Instagram en Facebook';
    case 'klanten': return custViaAi() ? (S.custAiSent ? `Kijk of ${AI_NAME[S.ai]} je klanten doorgaf` : `Laat ${AI_NAME[S.ai]} je klanten doorgeven`) : 'Voeg je klanten toe';
    case 'icp': return !S.icp.crit.length ? 'Beschrijf je ideale klant' : d < 3 ? `Kies nog ${d === 2 ? 'één droomklant' : (3 - d) + ' droomklanten'}` : 'Maak je ideale klant scherper';
    case 'team': return "Nodig een collega uit";
    case 'ai': return aiOn() ? `Zet de connector in ${AI_NAME[S.ai]}` : 'Koppel Claude of ChatGPT';
  }
  return '';
}
function tips() {
  return SOURCES.filter(s => srcScore(s.id) < s.max && !(s.id === 'ai' && (S.ai === 'none' || S.plan === 'free')) && !(s.id === 'klanten' && S.crm === 'geen'))
    .map(s => ({ s, t: tipFor(s.id), pts: s.max - srcScore(s.id) })).sort((x, y) => y.pts - x.pts);
}

/* ------------------------------------------------------------------ routes */
function resolve(h) {
  if (h === 'inloggen') return h;
  if (h === 'aanmelden') return S.account && !U.forceSignup ? (S.finished || S.parked ? 'vandaag' : nextOpen()) : h;
  if (!S.account) return 'aanmelden';
  if (!S.plan && h === 'partners') return h;
  if (!S.plan) return 'start-2';
  if (h === 'start-1') return 'instellingen';
  { const m = /^start-(\d+)$/.exec(h); if (m && +m[1] >= 2 && +m[1] <= STEPS.length) return h; }
  if (h === 'klaar') return h;
  if (['vandaag', 'netwerk', 'bronnen', 'instellingen', 'partners'].includes(h)) return h;
  return S.finished || S.parked ? 'vandaag' : nextOpen();
}
function go(h) { if (location.hash.slice(1) === h) render(); else location.hash = h; }
function titleFor(r) {
  if (r.startsWith('start-')) { const n = +r.split('-')[1]; return n === 2 ? 'Welkom' : `Stap ${n - 2} van ${DATA_STEPS.length}: ${STEPS[n - 1].t}`; }
  return { aanmelden: 'Aanmelden', inloggen: 'Inloggen', vandaag: 'Vandaag', netwerk: 'Netwerk', bronnen: 'Bronnen', instellingen: 'Instellingen', partners: 'Verdien mee', klaar: 'Je start' }[r] || BRAND;
}
let lastRoute = '';
function render() {
  const want = location.hash.slice(1);
  const r = resolve(want);
  if (r !== want) history.replaceState(null, '', '#' + r);
  const routeChanged = r !== lastRoute; lastRoute = r;
  /* onthoud waar de focus stond, zodat een nieuwe weergave je plek niet kwijtraakt */
  const ae = document.activeElement; let fsel = null, caret = null;
  if (!routeChanged && ae && ae !== document.body && ae.closest && ae.closest('#app')) {
    if (ae.id) fsel = '#' + CSS.escape(ae.id);
    else if (ae.dataset && ae.dataset.act) fsel = `[data-act="${ae.dataset.act}"]` + (ae.dataset.v != null ? `[data-v="${CSS.escape(ae.dataset.v)}"]` : '');
    try { if (typeof ae.selectionStart === 'number') caret = [ae.selectionStart, ae.selectionEnd]; } catch (e) { caret = null; }
  }
  let html = '';
  if (r === 'aanmelden') html = viewSignup();
  else if (r === 'inloggen') html = viewLogin();
  else if (r === 'klaar') html = viewKlaar();
  else if (r.startsWith('start-')) html = viewStep(+r.split('-')[1]);
  else html = viewApp(r);
  $('#app').innerHTML = html + designPanel();
  document.title = `${titleFor(r)} · ${BRAND}`;
  if (routeChanged) {
    const f = $('[data-autofocus]');
    if (f && !f.value) f.focus({ preventScroll: true });
    else { const h = $('#app h1'); if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); } }
  } else if (fsel) {
    const el = $(fsel);
    if (el) { el.focus({ preventScroll: true }); if (caret && el.setSelectionRange) try { el.setSelectionRange(caret[0], caret[1]); } catch (e) { /* niets */ } }
  }
}
/* alleen de knoppenbalk en de stappenbalk opnieuw tekenen, terwijl iemand typt */
function refreshChrome() {
  const n = curStep(); if (!n) return;
  const bar = $('.ob-main > .actbar'); if (bar) bar.outerHTML = actionBar(n);
  const sp = $('.stepper'); if (sp) sp.outerHTML = stepper(STEPS[n - 1].id);
}

/* ------------------------------------------------------------------ bouwstenen */
/* Eén keuzecomponent voor alle "kies er één": altijd alle opties zichtbaar, de gekozen optie met een gevulde stip, wisselen met één klik of met de pijltjes. */
function radios(name, label, value, act, opts, kind) {
  const lid = 'rg-' + name;
  const focusK = opts.some(o => o.k === value) ? value : opts[0].k;
  const items = opts.map(o => {
    const on = o.k === value; const tab = o.k === focusK ? 0 : -1;
    if (kind === 'tiles') return `<button type="button" class="ptile${on ? ' on' : ''}${o.wide ? ' wide' : ''}" role="radio" aria-checked="${on}" tabindex="${tab}" data-act="${act}" data-v="${esc(o.k)}"><span class="rdot" aria-hidden="true"></span><span>${esc(o.t)}</span></button>`;
    return `<button type="button" class="choice${on ? ' sel' : ''}" role="radio" aria-checked="${on}" tabindex="${tab}" data-act="${act}" data-v="${esc(o.k)}"><span class="ci">${ic(o.i)}</span><span class="ct"><b>${esc(o.t)}${o.b ? ` <em>${esc(o.b)}</em>` : ''}</b>${o.s ? `<small>${esc(o.s)}</small>` : ''}</span><span class="rdot" aria-hidden="true"></span></button>`;
  }).join('');
  return `<div class="field"><span class="lab" id="${lid}">${label}</span><div class="${kind === 'tiles' ? 'ptiles' : 'choices'}" role="radiogroup" aria-labelledby="${lid}">${items}</div></div>`;
}
/* een vinkje dat je ook weer uit kunt zetten: voor "ik heb het verstuurd" en "ik heb het aangevraagd" */
function checkRow(act, on, label, sub) {
  return `<button type="button" class="checkrow${on ? ' on' : ''}" role="checkbox" aria-checked="${on}" data-act="${act}"><span class="cb" aria-hidden="true">${on ? ic('check', 'currentColor', 3) : ''}</span><span class="ctx"><b>${label}</b>${sub ? `<small>${sub}</small>` : ''}</span></button>`;
}
function fileInput(kind, accept) { return `<input class="sr" type="file" id="f-${kind}" accept="${accept}">`; }
function dropZone(kind, title, sub, accept) {
  return `<div class="drop" data-drop="${kind}"><div class="dt"><b>${title}</b><span class="small muted">${sub}</span></div>
    ${fileInput(kind, accept)}<label class="btn btn-s" for="f-${kind}">${ic('up')} Kies een bestand</label></div>`;
}
function designLink() { return location.hostname === APP_HOST ? '' : ` <button type="button" class="linkbtn dzl" data-act="design" aria-expanded="${!!U.design}">Ontwerp bekijken</button>`; }
function foot() { return `<p class="foot">Concept. Alles wat je invoert blijft in deze browser; er gaat niets naar een server.${designLink()}</p>`; }
function designPanel() {
  if (location.hostname === APP_HOST || !U.design) return '';
  const screens = [['aanmelden', 'Aanmelden'], ['start-2', 'Welkom'], ...DATA_STEPS.map((s, i) => ['start-' + stepNo(s.id), `${i + 1}. ${s.t}`]), ['klaar', 'Je start'], ['vandaag', 'Vandaag'], ['netwerk', 'Netwerk'], ['bronnen', 'Bronnen'], ['instellingen', 'Instellingen']];
  return `<div class="dz"><div class="dz-panel" role="dialog" aria-label="Ontwerp bekijken"><div class="dz-h"><b>Ontwerp bekijken</b><button type="button" class="btn btn-g" data-act="design" aria-label="Sluit">${ic('x')}</button></div><span class="small muted">Spring naar een scherm. Alleen zichtbaar buiten app.fromyournetwork.com.</span>
    <div class="dz-list">${screens.map(([h, l]) => `<button type="button" data-act="jump" data-v="${h}">${l}</button>`).join('')}</div>
    <div class="btns"><button type="button" class="btn btn-s" data-act="demo">Vul een voorbeeldaccount</button><button type="button" class="btn btn-s" data-act="sample">Laad voorbeeldgegevens</button><button type="button" class="btn btn-g" data-act="reset">Begin opnieuw</button></div></div></div>`;
}

/* ------------------------------------------------------------------ aanmelden en inloggen */
function accountFields(a) {
  a = a || {};
  const e = U.err;
  return `<div class="grid2">
    <div class="field"><label for="f-name">Je naam</label><input class="input" id="f-name" autocomplete="name" value="${esc(a.name)}">${e.name ? `<span class="err">${esc(e.name)}</span>` : ''}</div>
    <div class="field"><label for="f-company">Bedrijf</label><input class="input" id="f-company" autocomplete="organization" value="${esc(a.company)}">${e.company ? `<span class="err">${esc(e.company)}</span>` : ''}</div>
    <div class="field"><label for="f-email">Werkmail</label><input class="input" id="f-email" type="email" autocomplete="email" value="${esc(a.email)}">${e.email ? `<span class="err">${esc(e.email)}</span>` : ''}</div>
    <div class="field"><label for="f-site">Website</label><input class="input" id="f-site" autocomplete="url" placeholder="jouwbedrijf.nl" value="${esc(a.website)}">${e.website ? `<span class="err">${esc(e.website)}</span>` : ''}</div>
  </div>`;
}
function guessCompany(dom) { return dom.replace(/\.[a-z.]+$/, '').split(/[-_.]/).map(w => w ? w[0].toUpperCase() + w.slice(1) : '').join(' '); }
function viewSignup() {
  const d = U.draft || (U.draft = { name: '', email: '', company: '', site: '' });
  const pp = U.pendingPlan && PLANS[U.pendingPlan] ? PLANS[U.pendingPlan].name : null;
  const e = U.err;
  return `<div class="auth2"><form class="auth-box" data-form="signup" novalidate>
    <a class="brand" href="${SITE}">${LOGO}<span>${WORD}</span></a>
    <div><h1 class="auth-h">${U.pendingPartner ? (U.pendingPartner === 'agency' ? 'Word partner' : 'Word verwijzer') : 'Begin gratis'}</h1>
    <p class="lead" style="margin-top:6px">${U.pendingPartner ? 'Maak eerst je account. Daarna meld je je aan en krijg je meteen je eigen link.' : `${pp ? `Je koos ${esc(pp)}. ` : ''}Binnen tien minuten zie je bij welke bedrijven je al iemand kent.`}</p>
    ${U.pendingRef ? `<p class="small refnote">${ic('check', 'var(--ok)', 2.4)}<span>Je komt via partner <b>${esc(U.pendingRef)}</b>: je probeert Growth ${PARTNER.clientTrialDays} dagen gratis.</span></p>` : ''}</div>
    <div class="field"><label for="f-name">Je naam</label><input class="input" id="f-name" autocomplete="name" value="${esc(d.name)}" data-autofocus>${e.name ? `<span class="err">${esc(e.name)}</span>` : ''}</div>
    <div class="field"><label for="f-email">Je werkmail</label><input class="input" id="f-email" type="email" autocomplete="email" placeholder="jan@jouwbedrijf.nl" value="${esc(d.email)}">${e.email ? `<span class="err">${esc(e.email)}</span>` : ''}</div>
    <div id="derived">${derivedHtml()}</div>
    <button class="btn btn-p big" type="submit">Maak mijn account</button>
    <div class="checks2"><span>${ic('check', 'var(--ok)', 2.4)}Geen betaalkaart</span><span>${ic('check', 'var(--ok)', 2.4)}Klaar in 10 minuten</span><span>${ic('check', 'var(--ok)', 2.4)}Je gegevens blijven van jou</span></div>
    <p class="small muted">Heb je al een account? <a class="tl44" href="#inloggen">Inloggen</a>. Inloggen met Google of LinkedIn komt later.${designLink()}</p>
  </form>
  <aside class="auth-value" aria-label="Wat je krijgt"><span class="k">Zo ziet een kans eruit</span>
    <div class="mini"><div class="mini-h"><span class="mono" style="background:#0E1330;width:34px;height:34px">N</span><b>Northpeak B.V.</b><span class="pill p-warm" style="margin-left:auto">Warme kans</span></div>
      <span class="small"><b>Waarom nu:</b> bekeek je prijspagina 3× deze week.</span><span class="small"><b>Je kent er:</b> Peter Jansen, sinds 2019.</span>
      <span class="callbtn2">${ic('phone', '#FFFFFF', 2)} Bel Peter</span></div>
    <ul class="vlist"><li>${ic('check', 'var(--vio)', 2.4)}Elke werkdag hooguit vijf kansen in je mail</li><li>${ic('check', 'var(--vio)', 2.4)}Via mensen die je al kent</li><li>${ic('check', 'var(--vio)', 2.4)}Je netwerk vergeet niets: ook over jaren</li></ul>
    <span class="small muted">Voorbeeld met verzonnen bedrijven.</span></aside></div>`;
}
function derivedHtml() {
  const d = U.draft || {}; const e = U.err;
  const dom = (d.email || '').includes('@') ? d.email.split('@')[1].toLowerCase().trim() : '';
  const freeMail = FREE_MAIL.test(d.email || '');
  const co = d.company || (dom && !freeMail ? guessCompany(dom) : ''), site = d.site || (freeMail ? '' : dom);
  if (U.editDerived || freeMail || e.company || e.website) {
    return `<div class="grid2"><div class="field"><label for="f-company">Bedrijf</label><input class="input" id="f-company" autocomplete="organization" value="${esc(co)}">${e.company ? `<span class="err">${esc(e.company)}</span>` : ''}</div>
      <div class="field"><label for="f-site">Website</label><input class="input" id="f-site" placeholder="jouwbedrijf.nl" value="${esc(site)}">${e.website ? `<span class="err">${esc(e.website)}</span>` : (freeMail ? '<span class="hint">Met je werkmail vullen we dit zelf in.</span>' : '')}</div></div>`;
  }
  if (!dom || !dom.includes('.')) return '';
  return `<div class="derived"><span>${ic('globe', 'var(--vio)')}<span>Bedrijf <b>${esc(co)}</b> · website <b>${esc(site)}</b></span></span><button type="button" class="btn btn-g" data-act="edit-derived">Wijzig</button></div>`;
}
function readSignup() {
  const d = U.draft || {};
  const name = (d.name || '').trim(), email = (d.email || '').trim();
  const dom = email.includes('@') ? email.split('@')[1].toLowerCase() : '';
  const freeMail = FREE_MAIL.test(email);
  const a = { name, email, company: (d.company || (dom && !freeMail ? guessCompany(dom) : '')).trim(), website: domainOf(d.site || (freeMail ? '' : dom)) };
  const e = {};
  if (!a.name) e.name = 'Vul je naam in.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a.email)) e.email = 'Vul een geldig mailadres in, bijvoorbeeld jan@jouwbedrijf.nl.';
  if (!e.email && !a.company) e.company = 'Vul de naam van je bedrijf in.';
  if (!e.email && (!a.website || !/\./.test(a.website))) e.website = 'Vul je website in, bijvoorbeeld jouwbedrijf.nl.';
  U.err = e;
  return Object.keys(e).length ? null : a;
}
function viewLogin() {
  return `<div class="auth"><form class="auth-box" data-form="login" novalidate>
    <a class="brand" href="${SITE}">${LOGO}<span>${WORD}</span></a>
    <div><h1 style="font-size:26px;font-weight:800">Inloggen</h1>
    <p class="lead" style="margin-top:6px">Straks krijg je een inloglink per mail. In dit concept staat je account in deze browser.</p></div>
    <div class="field"><label for="f-login">Werkmail</label><input class="input" id="f-login" type="email" autocomplete="email" data-autofocus></div>
    <button class="btn btn-p" type="submit">Stuur mij een inloglink</button>
    <p class="small muted">Nog geen account? <a class="tl44" href="#aanmelden">Maak er een</a></p>
  </form></div>`;
}
function readAccount() {
  const a = { name: $('#f-name').value.trim(), company: $('#f-company').value.trim(), email: $('#f-email').value.trim(), website: domainOf($('#f-site').value) };
  const e = {};
  if (!a.name) e.name = 'Vul je naam in.';
  if (!a.company) e.company = 'Vul de naam van je bedrijf in.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a.email)) e.email = 'Vul een geldig mailadres in, bijvoorbeeld jan@jouwbedrijf.nl.';
  if (!a.website || !/\./.test(a.website)) e.website = 'Vul je website in, bijvoorbeeld jouwbedrijf.nl.';
  U.err = e;
  return Object.keys(e).length ? null : a;
}

/* ------------------------------------------------------------------ de start: kader */
const GTM_STEPS = ['Open je container in <b>Google Tag Manager</b> en ga naar <b>Tags</b>, dan <b>Nieuw</b>.', 'Kies als tagtype <b>Aangepaste HTML</b> en plak je regel.', 'Kies als trigger <b>All Pages</b>, sla op en klik op <b>Verzenden</b> om te publiceren.'];
const PLATFORMS = {
  wordpress: ['WordPress', ['Installeer de gratis plugin <b>WPCode</b> (Plugins, Nieuwe plugin).', 'Ga naar <b>Code Snippets</b>, dan <b>Header &amp; Footer</b>.', 'Plak je regel bij <b>Header</b> en klik op <b>Opslaan</b>.']],
  wix: ['Wix', ['Ga naar <b>Instellingen</b>, dan <b>Aangepaste code</b>.', 'Klik op <b>+ Aangepaste code toevoegen</b> en plak je regel.', 'Kies <b>Alle pagina\'s</b> en <b>Head</b>, en klik op <b>Toepassen</b>. Dit kan op een Premium-abonnement met eigen domein.']],
  shopify: ['Shopify', ['Ga naar <b>Webwinkel</b>, dan <b>Thema\'s</b>.', 'Klik bij je thema op <b>...</b> en dan <b>Code bewerken</b>. Open <b>theme.liquid</b>.', 'Plak je regel vlak boven <b>&lt;/head&gt;</b> en klik op <b>Opslaan</b>.']],
  webflow: ['Webflow', ['Open <b>Site settings</b>, dan <b>Custom code</b>.', 'Plak je regel bij <b>Head code</b> en klik op <b>Save</b>.', 'Klik op <b>Publish</b>.']],
  squarespace: ['Squarespace', ['Ga naar <b>Instellingen</b>, dan <b>Geavanceerd</b>, dan <b>Code-injectie</b>.', 'Plak je regel bij <b>Header</b>.', 'Klik op <b>Opslaan</b>. Dit kan op een Business-abonnement of hoger.']],
  gtm: ['Google Tag Manager', GTM_STEPS],
  anders: ['Iets anders', ['Plak je regel in het kopgedeelte (<b>&lt;head&gt;</b>) van elke pagina.', 'Weet je niet waar dat is? Kies bovenaan <b>Mijn webbouwer</b>; dan zetten wij een mail voor je klaar.']],
};
const LI_DOWNLOAD = 'https://www.linkedin.com/mypreferences/d/download-my-data';
function snippetText() { return `<script async src="https://${APP_HOST}/s/${slugOf(S.account && S.account.website)}.js"></script>`; }
function builderText() {
  const site = (S.account && S.account.website) || 'onze site';
  return `Hoi,\n\nWil je deze regel in het kopgedeelte (<head>) van elke pagina van ${site} zetten?\n\n${snippetText()}\n\nHet is het script van ${BRAND}. Het zet geen cookies, bewaart niets in de browser en herkent alleen bedrijven, nooit personen.\n\nDank je wel!\n${S.account ? S.account.name : ''}`;
}
function builderHref() { return `mailto:${encodeURIComponent(S.site.builder || '')}?subject=${encodeURIComponent('Eén regel code voor onze site')}&body=${encodeURIComponent(builderText())}`; }

/* het netwerkpaneel: elke bron die je koppelt, licht op */
const NODE_POS = SOURCES.map((s, i) => { const a = (-90 + i * 360 / SOURCES.length) * Math.PI / 180; return [Math.round(160 + 112 * Math.cos(a)), Math.round(125 + 82 * Math.sin(a))]; });
function netSvg(cur) {
  const nodes = SOURCES.map((s, i) => {
    const [x, y] = NODE_POS[i]; const on = srcScore(s.id) >= s.max * 0.6; const part = !on && srcScore(s.id) > 0; const c = s.id === cur;
    return { s, x, y, on, part, c, ly: y < 125 ? y - 25 : y + 32 };
  });
  const lines = nodes.map(n => `<line class="ln${n.on ? ' on' : n.part ? ' part' : ''}" x1="${n.x}" y1="${n.y}" x2="160" y2="125"/>`).join('');
  const dots = nodes.map(n => `<g class="nd${n.on ? ' on' : n.part ? ' part' : ''}${n.c ? ' cur' : ''}">${n.c ? `<circle class="pulse" cx="${n.x}" cy="${n.y}" r="19"/>` : ''}<circle cx="${n.x}" cy="${n.y}" r="17"/><g transform="translate(${n.x - 9} ${n.y - 9}) scale(.75)" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${I[n.s.icon]}</g><text x="${n.x}" y="${n.ly}" text-anchor="middle">${esc(n.s.short || n.s.t)}</text></g>`).join('');
  return `<svg class="netsvg" viewBox="0 0 320 250" role="img" aria-label="Je bronnen: ${SOURCES.map(s => s.t + (srcScore(s.id) >= s.max * 0.6 ? ' gekoppeld' : ' nog niet')).join(', ')}">
    <defs><radialGradient id="orbg" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".25" stop-color="#C9C2FF"/><stop offset=".7" stop-color="#6C5CE7"/><stop offset="1" stop-color="#3E7BFA"/></radialGradient>
    <radialGradient id="orbglow"><stop offset="0" stop-color="#6C5CE7" stop-opacity=".35"/><stop offset="1" stop-color="#6C5CE7" stop-opacity="0"/></radialGradient></defs>
    ${lines}<circle cx="160" cy="125" r="${30 + strength() / 5}" fill="url(#orbglow)"/><circle cx="160" cy="125" r="26" fill="url(#orbg)"/>${dots}</svg>`;
}
function seenNow() {
  const out = []; const s = realLi().length ? latest() : null; const cust = realCust();
  if (s) { const m = companies(s); out.push(`${plural(s.rows.length, 'mens', 'mensen')} bij ${plural(m.size, 'bedrijf', 'bedrijven')}`); }
  if (s && S.dream.length) { const m = companies(s); const n = S.dream.filter(d => findCo(m, d)).length; if (n) out.push(`${plural(n, 'droomklant', 'droomklanten')} met een ingang`); }
  if (cust) { const c = {}; for (const r of cust.rows) c[r[3]] = (c[r[3]] || 0) + 1; if (c.oud) out.push(plural(c.oud, 'oud-klant', 'oud-klanten')); if (c.offerte) out.push(plural(c.offerte, 'open offerte', 'open offertes')); }
  if (S.meta.followers) out.push(plural(S.meta.followers.rows.length, 'volger', 'volgers') + ' op Instagram');
  if (S.meta.connected) out.push('Instagram en Facebook gekoppeld');
  if (S.site.verified) out.push('je site, live');
  if (S.team.length) out.push(`${plural(S.team.length, 'collega', "collega's")} erbij`);
  return out;
}
function panel(curId) {
  const n = strength(); const seen = seenNow(); const src = SOURCES.find(x => x.id === curId);
  const gain = src ? src.max - srcScore(src.id) : 0;
  return `<div class="np"><div class="np-h"><b>Je netwerk</b><span class="pill ${n >= 60 ? 'p-warm' : 'p-net'}">${strengthLabel(n)}</span></div>
    ${netSvg(curId)}
    <div class="meter"><div class="mrow"><span>Sterkte van je bronnen</span><b class="num">${n}<small>/100</small></b></div><div class="bar" role="progressbar" aria-label="Sterkte van je bronnen" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${n}"><i style="width:${n}%"></i></div>
    <span class="small muted">Hoe sterker je bronnen, hoe meer kansen we vinden.</span></div>
    ${src ? `<div class="gain">${gain > 0 ? `<span>Deze stap: <b class="num">+${gain}</b></span>` : `<span>${ic('check', 'var(--ok)', 2.4)} Deze bron staat</span>`}<span class="small muted">${esc(src.why)}</span></div>` : ''}
    ${seen.length ? `<div class="seen"><span class="k">Wat we nu al zien</span>${seen.map(x => `<span>${ic('check', 'var(--ok)', 2.4)}${esc(x)}</span>`).join('')}</div>` : ''}</div>`;
}
/* de stappenbalk: altijd klikbaar, met per stap de echte stand */
function stepper(cur) {
  const items = DATA_STEPS.map((s, i) => {
    const st = stepStatus(s.id); const sk = st === 'todo' && S.skipped[s.id]; const isCur = s.id === cur;
    const prevOn = i > 0 && isReady(DATA_STEPS[i - 1].id);
    const mark = st === 'done' ? ic('check', 'currentColor', 2.8) : st === 'wait' ? ic('clock', 'currentColor', 2.2) : String(i + 1);
    const say = st === 'done' ? 'klaar' : st === 'wait' ? 'wacht op iemand anders' : st === 'partial' ? 'bezig' : sk ? 'overgeslagen' : 'nog te doen';
    return `<li class="${prevOn ? 'ln-on' : ''}"><button type="button" class="sp-b st-${st}${sk ? ' st-skip' : ''}" data-act="step" data-v="${stepNo(s.id)}" ${isCur ? 'aria-current="step"' : ''} aria-label="Stap ${i + 1}, ${esc(s.t)}: ${say}"><span class="sp-n">${mark}</span><span class="sp-t">${esc(s.t)}</span></button></li>`;
  }).join('');
  return `<nav class="stepper" aria-label="Je start, ${doneCount()} van ${DATA_STEPS.length} klaar"><ol style="grid-template-columns:repeat(${DATA_STEPS.length},minmax(0,1fr))">${items}</ol></nav>`;
}
function obHeader(cur, noLater) {
  const n = cur && cur !== 'klaar' ? stepNo(cur) - 2 : 0;
  return `<header class="ob-top"><a class="brand" href="${SITE}">${LOGO}<span>${WORD}</span></a>
    ${cur ? stepper(cur) : '<span></span>'}
    ${S.plan && !noLater && !U.ret ? `<button type="button" class="btn btn-g" data-act="later">${S.finished ? 'Naar je overzicht' : 'Later afmaken'}</button>` : '<span></span>'}</header>
    ${cur && cur !== 'klaar' ? ` <p class="sp-mob">Stap <b>${n}</b> van ${DATA_STEPS.length} · ${esc(STEPS[stepNo(cur) - 1].t)}</p>` : ''}`;
}
const LATER = {
  site: 'Zonder script zien we niet welke bedrijven je site bezoeken.',
  linkedin: 'Zonder LinkedIn weten we niet wie je kent.',
  meta: 'Zonder Meta zien we niet wie je volgt, een bericht stuurt of reageert.',
  klanten: 'Zonder klanten missen we je oud-klanten en open offertes.',
  icp: 'Zonder ideale klant weten we niet welke bedrijven bij je passen.',
  team: "Collega's kun je ook later uitnodigen.",
  ai: 'Zonder koppeling voeg je je klanten straks toe met een export.',
};
const PARTIAL = {
  site: () => S.site.who === 'zelf' ? 'Nog niet gecontroleerd. Dat kan ook later, in Bronnen.' : S.site.who === 'bouwer' ? 'Nog niet naar je webbouwer gestuurd.' : 'Kies je tool om dit af te ronden.',
  klanten: () => custViaAi() ? `Geef ${AI_NAME[S.ai]} de opdracht, of kies voor een export.` : 'Nog geen bestand toegevoegd.',
  ai: () => 'Vink aan zodra de connector erin staat.',
  icp: () => !S.icp.crit.length ? 'Nog geen criteria gemaakt.' : 'Kies nog minstens één droomklant.',
};
/* wat er nog half getypt staat; "Verder" bewaart het eerst, in plaats van het weg te gooien */
function pending(id) {
  if (id === 'icp') {
    const t = S.icp.text.trim(); const needCrit = t.length >= 20 && S.icp.critFrom !== t; const dd = (U.dreamDraft || '').trim();
    if (needCrit && dd) return 'Bewaar';
    if (needCrit) return S.icp.crit.length ? 'Werk je criteria bij' : 'Maak je criteria';
    if (dd) return `Voeg ${dd.length > 24 || /[,;\n]/.test(dd) ? 'ze' : esc(dd)} toe`;
  }
  if (id === 'team') { const d = U.tm || {}; if ((d.name || '').trim() || (d.email || '').trim()) return `Nodig ${(d.name || '').trim() ? esc(firstName(d.name)) : 'je collega'} uit`; }
  if (id === 'klanten' && U.custDraft) return 'Voeg je klanten toe';
  return null;
}
function commitPending(id) {
  if (id === 'icp') {
    const t = S.icp.text.trim();
    if (t.length >= 20 && S.icp.critFrom !== t) { S.icp.crit = mergeCrit(makeCrit(t)); S.icp.critFrom = t; }
    if ((U.dreamDraft || '').trim()) addDreams(true);
  }
  if (id === 'team') { const d = U.tm || {}; if ((d.name || '').trim() || (d.email || '').trim()) { if (!addTeam(true)) return false; } }
  if (id === 'klanten' && U.custDraft) { if (!confirmMapping(true)) return false; }
  save(); return true;
}
function actionBar(n) {
  const id = STEPS[n - 1].id, st = stepStatus(id), pend = pending(id);
  const ret = U.ret || (S.finished ? 'vandaag' : null);
  const retLabel = { klaar: 'je start', vandaag: 'je overzicht', bronnen: 'Bronnen', netwerk: 'je netwerk', instellingen: 'Instellingen' }[ret] || 'je overzicht';
  const last = n === STEPS.length; const nextT = last ? '' : STEPS[n].t;
  const nextLabel = last ? 'Rond je start af' : 'Volgende: ' + esc(nextT);
  let main, note = '';
  if (ret) main = `${last ? '' : `<button type="button" class="btn btn-s" data-act="next">${nextLabel}</button>`}<button type="button" class="btn btn-p" data-act="ret">${pend ? 'Bewaar en ga terug' : 'Terug naar ' + retLabel}</button>`;
  else if (pend) main = `<button type="button" class="btn btn-p" data-act="next">${pend} en ga verder</button>`;
  else if (st === 'done' || st === 'wait') main = `<button type="button" class="btn btn-p" data-act="next">${nextLabel}</button>`;
  else if (st === 'partial') { main = `<button type="button" class="btn btn-s" data-act="next">${nextLabel}</button>`; note = PARTIAL[id] ? PARTIAL[id]() : ''; }
  else { main = `<button type="button" class="btn btn-s" data-act="skip">${last ? 'Doe dit later en rond af' : 'Doe dit later'}</button>`; note = LATER[id]; }
  const back = ret ? '<span></span>' : `<button type="button" class="btn btn-s" data-act="back">Terug</button>`;
  return `<div class="actbar">${back}<div class="ab-r">${note ? `<span class="ab-note">${esc(note)}</span>` : ''}${main}</div></div>`;
}
function viewStep(n) {
  const step = STEPS[n - 1];
  if (step.id === 'plan') return viewWelcome();
  const body = ({ site: stepSite, linkedin: stepLinkedIn, meta: stepMeta, klanten: stepKlanten, icp: stepIcp, team: stepTeam, ai: stepAi })[step.id]();
  return `<div class="ob">${obHeader(step.id)}
    <div class="ob-grid"><section class="ob-main" aria-labelledby="st-h"><div class="ob-body">${body}</div>${actionBar(n)}</section>
    <aside class="ob-side" aria-label="Sterkte van je bronnen">${panel(step.id)}</aside></div>
    ${foot()}</div>`;
}

/* ------------------------------------------------------------------ welkom: kies hoe je begint */
function viewWelcome() {
  const name = S.account ? firstName(S.account.name) : '';
  const sel = U.planPick || S.plan || 'growth';
  const opts = [
    { k: 'growth', i: 'spark', t: `Growth, ${trialDays()} dagen gratis`, s: `Elke werkdag je kansen · ${PLANS.growth.recog} herkende bedrijven per maand · ${PLANS.growth.users} gebruikers · Claude en ChatGPT`, b: 'Aanbevolen' },
    { k: 'free', i: 'users', t: 'Free', s: '1 kans per week · 1 gebruiker · altijd gratis' },
  ];
  const label = S.plan === sel ? 'Volgende: Website' : sel === 'growth' ? `Start mijn ${trialDays()} dagen gratis` : 'Begin met Free';
  return `<div class="ob">${obHeader(null)}
    <section class="ob-main welcome" aria-labelledby="st-h"><div class="ob-body">
      <h1 id="st-h">Welkom${name ? ', ' + esc(name) : ''}.</h1>
      <p class="lead">Je account staat. Kies hoe je begint; je kunt dit altijd wijzigen.</p>
      ${radios('plan', 'Hoe wil je beginnen?', sel, 'plan-pick', opts, 'cards')}
      <p class="small muted">${sel === 'growth' ? `Geen betaalkaart. De ${trialDays()} dagen beginnen bij je eerste bron. Daarna kies je zelf: ${euro(PLANS.growth.price)} per maand, of gratis verder met Free.` : `Je kunt later altijd Growth proberen, ${trialDays()} dagen gratis.`}</p>
      <div class="road3"><span class="k">Daarna: ${NUM[DATA_STEPS.length]} korte stappen, samen ongeveer tien minuten</span><ol>${DATA_STEPS.map((s, i) => `<li><span class="rn">${i + 1}</span><span><b>${esc(s.t)}</b> <small>${esc(s.d)}</small></span></li>`).join('')}</ol></div>
    </div><div class="actbar"><span></span><div class="ab-r"><button type="button" class="btn btn-p big" data-act="plan-go">${label}</button></div></div></section>
    ${foot()}</div>`;
}

/* ------------------------------------------------------------------ stap 1: website */
const WHO = [
  { k: 'bouwer', i: 'users', t: 'Mijn webbouwer', s: 'Wij zetten een mail voor je klaar. Jij stuurt hem door.', b: 'Makkelijkst' },
  { k: 'zelf', i: 'code', t: 'Ik doe het zelf', s: 'Twee minuten, met uitleg voor jouw website.' },
  { k: 'own', i: 'globe', t: 'Ik gebruik al een tool voor websitebezoekers', s: 'Houd je tool. Wij gebruiken die herkenningen.' },
];
function verifyCard() {
  const v = S.site.verified, busy = U.checking;
  const t = S.site.verifiedAt ? new Date(S.site.verifiedAt) : null;
  return `<div class="verify${v ? ' ok' : ''}" aria-live="polite"><span class="vdot${v ? ' ok' : busy ? ' busy' : ''}" aria-hidden="true"></span>
    <div class="vt"><b>${v ? 'We zien je site' : busy ? 'We kijken of je site het script laadt…' : 'We zien je site nog niet'}</b>
    <span class="small muted">${v ? `Eerste bezoek gezien om ${t ? String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0') : ''}. Vanaf nu verzamelt het script, ook als je dit venster sluit.` : 'Heb je de regel geplaatst? Open je site één keer in een ander tabblad en controleer het dan.'}</span>
    ${v ? '<span class="pill p-new" style="align-self:flex-start">Concept: deze controle is nagebootst</span>' : ''}</div>
    <button type="button" class="btn ${v ? 'btn-g' : 'btn-s'}" data-act="verify" ${busy ? 'disabled' : ''}>${v ? 'Controleer opnieuw' : 'Controleer mijn site'}</button></div>`;
}
function stepSite() {
  const who = S.site.who; let pane = '';
  if (who === 'zelf') {
    const p = S.site.platform;
    pane = `${radios('platform', 'Waar is je website mee gemaakt?', p, 'platform', Object.entries(PLATFORMS).map(([k, v]) => ({ k, t: v[0] })), 'tiles')}
      ${p ? `<ol class="flow">
        <li><span class="fn">1</span><div class="fb2"><b>Kopieer je regel</b><div class="codebox"><div class="code" id="snip">${esc(snippetText())}</div><button type="button" class="btn btn-p" data-act="copy" data-v="snip">${ic('copy', 'currentColor')} Kopieer</button></div></div></li>
        <li><span class="fn">2</span><div class="fb2"><b>Plak hem in ${esc(PLATFORMS[p][0])}</b><ol class="howl">${PLATFORMS[p][1].map(x => `<li>${x}</li>`).join('')}</ol></div></li>
        <li><span class="fn">3</span><div class="fb2"><b>Controleer of het werkt</b>${verifyCard()}</div></li></ol>` : ''}`;
  } else if (who === 'bouwer') {
    const sent = !!S.site.builderSent;
    pane = `<ol class="flow">
      <li><span class="fn">1</span><div class="fb2"><label for="f-builder"><b>Mailadres van je webbouwer</b></label><input class="input" id="f-builder" type="email" autocomplete="off" value="${esc(S.site.builder)}" placeholder="naam@webbureau.nl"><span class="hint">Mag ook leeg blijven; dan vul je het in je mailprogramma in.</span></div></li>
      <li><span class="fn">2</span><div class="fb2"><b>Stuur hem het bericht</b><span class="small muted">Het staat klaar, met je persoonlijke regel erin. Jij verstuurt het vanuit je eigen mail.</span>
        <div class="btns"><a class="btn btn-p" id="mailto" href="${esc(builderHref())}">${ic('mail', 'currentColor')} Open in je mailprogramma</a><button type="button" class="btn btn-s" data-act="copy" data-v="bmsg">${ic('copy')} Kopieer het bericht</button></div>
        <details class="help"><summary>Bekijk het bericht</summary><div class="code msg" id="bmsg">${esc(builderText())}</div></details>
        ${checkRow('sent', sent, 'Ik heb het verstuurd', sent ? 'We laten het je weten zodra we je site zien.' : 'Vink aan als de mail de deur uit is.')}</div></li>
      ${sent ? `<li><span class="fn">3</span><div class="fb2"><b>Als je webbouwer klaar is</b>${verifyCard()}</div></li>` : ''}</ol>`;
  } else if (who === 'own') {
    pane = `${radios('tool', 'Welke tool gebruik je?', S.site.tool, 'tool', ['Leadinfo', 'Leadfeeder', 'Snitcher', 'Iets anders'].map(t => ({ k: t, t })), 'tiles')}
      ${S.site.tool === 'Iets anders' ? `<div class="field" style="max-width:360px"><label for="f-tool-other">Welke tool?</label><input class="input" id="f-tool-other" value="${esc(S.site.toolOther)}" placeholder="Naam van je tool"></div>` : ''}
      ${toolOk() ? `<div class="note ok">${ic('check', 'var(--ok)', 2.4)}<span>Genoteerd: ${esc(S.site.tool === 'Iets anders' ? S.site.toolOther : S.site.tool)}. Hoe we koppelen verschilt per tool; bij de livegang krijg je de stap die bij jouw tool hoort.</span></div>` : ''}`;
  }
  return `<h1 id="st-h">Zie welke bedrijven je site bezoeken</h1>
    <p class="lead">Met één regel code op je site, of via de tool die je al hebt. Het script verzamelt meteen, ook terwijl jij de rest doet.</p>
    ${radios('who', 'Wie zet de code op je site?', who, 'who', WHO, 'cards')}
    ${pane ? `<div class="pane2" id="pane">${pane}</div>` : ''}
    <p class="trust2">${ic('lock', 'var(--ok)')}<span>Geen cookies · alleen bedrijven, nooit personen · volgt je cookiebanner${who && who !== 'own' ? ' · je regel vind je later terug in Bronnen' : ''}</span></p>`;
}

/* ------------------------------------------------------------------ stap 2: LinkedIn */
function miniYears() {
  const s = latest(); if (!s) return '';
  const years = {}; for (const r of s.rows) if (r[5]) { const y = r[5].slice(0, 4); years[y] = (years[y] || 0) + 1; }
  const ys = Object.keys(years).sort(); if (ys.length < 2) return '';
  const max = Math.max(...Object.values(years));
  return `<div class="miniyears" role="img" aria-label="Nieuwe connecties per jaar, ${ys[0]} tot ${ys[ys.length - 1]}">${ys.map(y => `<i style="height:${Math.max(6, Math.round(years[y] / max * 48))}px" title="${y}: ${years[y]}"></i>`).join('')}</div><div class="miniyl small muted"><span>${ys[0]}</span><span>${ys[ys.length - 1]}</span></div>`;
}
function liSummary() {
  const s = latest(); if (!s) return '';
  const m = companies(s); const yrs = s.rows.map(r => r[5]).filter(Boolean).map(d => +d.slice(0, 4));
  return `${plural(s.rows.length, 'mens', 'mensen')} bij ${plural(m.size, 'bedrijf', 'bedrijven')}${yrs.length ? `, connecties van ${Math.min(...yrs)} tot ${Math.max(...yrs)}` : ''}.`;
}
function sampleNote() { return S.sample ? `<div class="note warn">${ic('info', 'var(--warn)')}<span>Ontwerpweergave: er staan voorbeeldgegevens in Vandaag en Netwerk. Ze tellen niet mee voor je start.</span>${confirmBtn('sample', 'Wis ze')}</div>` : ''; }
function stepLinkedIn() {
  const list = realLi().sort((a, b) => (a.date < b.date ? -1 : 1)); const req = !!S.liRequested;
  const priv = `<p class="trust2">${ic('lock', 'var(--ok)')}<span>We bewaren naam, bedrijf, functie en de datum van de connectie. Geen mailadressen. We loggen nooit in op je LinkedIn.</span></p>`;
  const head = `<h1 id="st-h">Voeg je LinkedIn-netwerk toe</h1><p class="lead">Zo weten we wie je kent, bij welk bedrijf en sinds wanneer.</p>`;
  const err = U.err.li ? `<span class="err" role="alert">${esc(U.err.li)}</span>` : '';
  if (list.length) {
    return `${head}${sampleNote()}
      <div class="success">${ic('check', 'var(--ok)', 2.4)}<div><b>${esc(liSummary())}</b>${miniYears()}</div></div>
      <div class="files"><span class="lab">Je exports</span>${list.slice().reverse().map(s => `<div class="frow">${ic('users')}<span class="ft"><b>${esc(s.file)}</b><small>${plural(s.rows.length, 'mens', 'mensen')} · toegevoegd op ${fmtDate(s.date)}</small></span><span class="btns">${confirmBtn('li:' + s.id, 'Verwijder')}</span></div>`).join('')}</div>
      ${dropZone('li', 'Nieuwe export toevoegen', 'Doe dit elke maand: dan zien we wie van baan wisselde. De oude blijft bewaard.', '.csv,.zip')}${err}${priv}`;
  }
  return `${head}${sampleNote()}
    <ol class="flow">
      <li><span class="fn">1</span><div class="fb2"><b>Vraag je export aan bij LinkedIn</b><span class="small muted">Kies alleen <b>Connecties</b> en klik op <b>Archief aanvragen</b>. LinkedIn mailt je, meestal binnen een dag. Ga intussen gewoon verder.</span>
        <div class="btns"><a class="btn btn-p" href="${LI_DOWNLOAD}" target="_blank" rel="noopener">Open LinkedIn ${ic('chev', 'currentColor')}</a></div>
        ${checkRow('li-req', req, 'Ik heb mijn export aangevraagd', req ? `Aangevraagd op ${fmtDate(S.liRequested)}. We herinneren je eraan.` : 'Vink aan als je op Archief aanvragen hebt geklikt.')}</div></li>
      <li><span class="fn">2</span><div class="fb2"><b>Sleep de zip hierheen</b>${dropZone('li', 'Zip of Connections.csv', 'Uitpakken hoeft niet. Heb je hem al? Dan kan het meteen.', '.csv,.zip')}${err}</div></li>
    </ol>
    ${req ? '<div class="later-row"><span class="small muted">Nog geen zip? Ga gewoon verder; zodra LinkedIn mailt, herinneren we je eraan.</span><button type="button" class="btn btn-s" data-act="li-later">Doe dit later</button></div>' : ''}
    ${priv}`;
}

/* ------------------------------------------------------------------ stap 3: klanten */
const CRM_STEPS = {
  hubspot: ['HubSpot', ['Ga naar <b>CRM</b>, dan <b>Contacts</b>.', 'Kies de weergave <b>All</b> en klik op <b>Export</b>.', 'Kies <b>CSV</b>. Je krijgt een mail met de download.']],
  pipedrive: ['Pipedrive', ['Open je accountmenu, dan <b>Tools and apps</b>, dan <b>Export data</b>.', 'Kies <b>People</b> en dan <b>CSV</b>.', 'Klik op <b>Export</b> en download het bestand.']],
  teamleader: ['Teamleader', ['Ga naar <b>Contacts</b> of <b>Companies</b>.', 'Klik op <b>Export</b> en dan <b>Start export</b>.', 'Download het bestand.']],
  salesforce: ['Salesforce', ['Maak een rapport met je accounts en contacten.', 'Klik op <b>Export</b>, kies <b>Details Only</b> en <b>CSV</b>.', 'Download het bestand.']],
  excel: ['Excel of Sheets', ['Open je klantenlijst.', 'Kies <b>Bestand</b>, dan <b>Opslaan als</b> (of <b>Downloaden</b>).', 'Kies <b>CSV</b>.']],
  anders: ['Iets anders', ['Zoek in je pakket naar <b>Export</b> of <b>Exporteren</b>.', 'Kies <b>CSV</b>. Is het Excel, sla het dan op als CSV.', 'Sleep het bestand hieronder.']],
  geen: ['Ik heb geen klantenlijst', []],
};
const CLS1 = { klant: 'klant', oud: 'oud-klant', offerte: 'open offerte', prospect: 'prospect', overig: 'overig' };
function custSummary() {
  if (!S.cust) return '';
  const c = {}; for (const r of S.cust.rows) c[r[3]] = (c[r[3]] || 0) + 1;
  return Object.keys(CLS).filter(k => c[k]).map(k => k === 'overig' ? `${nf(c[k])} overig` : plural(c[k], CLS1[k], CLS[k])).join(', ') + '.';
}
function mappingUI() {
  const d = U.custDraft; if (!d) return '';
  const name = i => i >= 0 ? `"${esc(d.headers[i] || 'Kolom ' + (i + 1))}"` : '<span class="muted">niet gevonden</span>';
  const err = U.err.map ? `<span class="err" role="alert">${esc(U.err.map)}</span>` : '';
  if (!U.mapEdit && d.map.company >= 0) {
    return `<div class="card"><b>We hebben je bestand gelezen. Klopt dit?</b><span class="small muted">${esc(d.file)} · ${plural(d.rows.length, 'rij', 'rijen')}</span>
      <ul class="maplist"><li>Bedrijf: ${name(d.map.company)}</li><li>Contactpersoon: ${name(d.map.contact)}</li><li>Status: ${name(d.map.status)}</li><li>Mailadres: ${name(d.map.email)} <span class="muted">(we bewaren alleen het domein)</span></li></ul>${err}
      <div class="btns"><button type="button" class="btn btn-p" data-act="map-ok">Klopt, voeg toe</button><button type="button" class="btn btn-s" data-act="map-edit">Pas de kolommen aan</button><button type="button" class="btn btn-g" data-act="map-cancel">Ander bestand kiezen</button></div></div>`;
  }
  const opts = sel => `<option value="-1">Niet gebruiken</option>` + d.headers.map((h, i) => `<option value="${i}" ${sel === i ? 'selected' : ''}>${esc(h || 'Kolom ' + (i + 1))}</option>`).join('');
  const f = [['company', 'Bedrijf'], ['contact', 'Contactpersoon'], ['email', 'Mailadres (alleen het domein)'], ['status', 'Status of soort']];
  const prev = d.rows.slice(0, 3).map(r => `<tr>${d.headers.map((_, i) => `<td>${esc(r[i] || '')}</td>`).join('')}</tr>`).join('');
  return `<div class="card"><b>Welke kolom is wat?</b><span class="small muted">${esc(d.file)} · ${plural(d.rows.length, 'rij', 'rijen')}</span>
    <div class="map">${f.map(([k, l]) => `<div class="field"><label for="map-${k}">${l}</label><select class="input" id="map-${k}">${opts(d.map[k])}</select></div>`).join('')}</div>
    <div class="scroll"><table class="tbl small"><thead><tr>${d.headers.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${prev}</tbody></table></div>${err}
    <div class="btns"><button type="button" class="btn btn-p" data-act="map-ok">Klopt, voeg toe</button>${d.map.company >= 0 || U.mapEdit ? '<button type="button" class="btn btn-g" data-act="map-back">Terug naar de samenvatting</button>' : ''}<button type="button" class="btn btn-g" data-act="map-cancel">Ander bestand kiezen</button></div></div>`;
}
function stepKlanten() {
  const crm = S.crm || '';
  const err = U.err.cust ? `<span class="err" role="alert">${esc(U.err.cust)}</span>` : '';
  let pane = '';
  const cust = realCust(); const nm = aiOn() ? AI_NAME[S.ai] : ''; const canAi = !!nm && AI_CRMS.includes(crm);
  const crmName = crm && CRM_STEPS[crm] ? (crm === 'anders' ? 'je CRM' : CRM_STEPS[crm][0]) : '';
  const exportFlow = () => `<ol class="flow"><li><span class="fn">1</span><div class="fb2"><b>Exporteer uit ${esc(CRM_STEPS[crm][0])}</b><ol class="howl">${CRM_STEPS[crm][1].map(x => `<li>${x}</li>`).join('')}</ol></div></li>
    <li><span class="fn">2</span><div class="fb2"><b>Sleep het bestand hierheen</b>${dropZone('cust', 'Je export, als CSV', 'Wij lezen de kolommen zelf; jij bevestigt alleen.', '.csv,.txt')}${err}</div></li></ol>`;
  const aiFlow = () => `<ol class="flow">
    <li><span class="fn">1</span><div class="fb2"><b>Zorg dat ${esc(crmName)} gekoppeld is in ${nm}</b><span class="small muted">In ${nm}: Instellingen, Connectors, kies ${esc(crmName)}. Staat hij er al? Dan kun je meteen door.</span>
      ${S.aiLinked ? '' : `<span class="small">${BRAND} zelf staat nog niet in ${nm}. <button type="button" class="linkbtn inl" data-act="step" data-v="${stepNo('ai')}">Doe dat eerst, in stap ${stepNo('ai') - 2}</button></span>`}</div></li>
    <li><span class="fn">2</span><div class="fb2"><b>Geef ${nm} deze ene opdracht</b><span class="small muted">Je klanten komen nu binnen, en daarna ververst ${nm} ze zelf elke werkdag.</span><div class="codebox"><div class="code" id="prompt1">Lees mijn klanten, oud-klanten en open offertes uit ${esc(crmName)} en geef ze door aan ${BRAND}: alleen naam, bedrijf, relatie en datum. Maak daarna een geplande taak die dit elke werkdag om ${refreshTime()} herhaalt en alleen doorgeeft wat nieuw of veranderd is.</div><button type="button" class="btn btn-s" data-act="copy" data-v="prompt1">${ic('copy')} Kopieer</button></div>
      <details class="help"><summary>Werkt plannen in mijn ${nm}?</summary><p class="small">${S.ai === 'chatgpt' ? 'ChatGPT maakt er zelf een taak van, op Plus, Pro, Business en Enterprise. Een taak die lang niet gebruikt wordt, kan ChatGPT pauzeren; dan sturen we je een seintje.' : 'Claude maakt er een geplande taak van in de desktop-app (Cowork) of in Claude Code. Lukt plannen niet in jouw Claude? Geef de opdracht dan af en toe zelf; we herinneren je eraan.'}</p></details>
      ${checkRow('cust-ai-sent', !!S.custAiSent, 'Ik heb de opdracht gegeven', S.custAiSent ? `${nm} ververst je klanten nu elke werkdag om ${refreshTime()}, voor je kansenmail.` : `Vink aan als je de opdracht in ${nm} hebt geplakt.`)}</div></li></ol>`;
  if (U.custDraft) pane = mappingUI();
  else if (cust) pane = `<div class="success">${ic('check', 'var(--ok)', 2.4)}<div><b>${esc(custSummary())}</b><span class="small muted">We koppelen ze aan je netwerk op bedrijfsnaam. Komt alleen de naam van een persoon overeen, dan vragen we het je eerst.</span></div></div>
    <div class="frow">${ic('crm')}<span class="ft"><b>${esc(cust.file)}</b><small>${plural(cust.rows.length, 'rij', 'rijen')} · toegevoegd op ${fmtDate(cust.date)}</small></span><span class="btns">${fileInput('cust', '.csv,.txt')}<label class="btn btn-g" for="f-cust">Vervang</label>${confirmBtn('cust', 'Verwijder')}</span></div>${err}`;
  else if (crm === 'geen') pane = `<div class="note">${ic('info', 'var(--vio)')}<span>Geen probleem. Heb je later wel een lijst, dan voeg je hem toe in Bronnen.</span></div>`;
  else if (crm && canAi) {
    const via = S.custVia || '';
    pane = `${radios('via', `Hoe komen je klanten uit ${esc(crmName)} bij ons?`, via, 'cust-via', [{ k: 'ai', i: 'spark', t: `Via ${nm}`, s: 'Geen export nodig. Je geeft één opdracht.', b: 'Makkelijkst' }, { k: 'file', i: 'up', t: 'Met een export', s: 'Twee minuten: exporteren en uploaden.' }], 'cards')}
      ${via === 'ai' ? aiFlow() : via === 'file' ? exportFlow() : ''}`;
  } else if (crm) pane = `${exportFlow()}
    ${AI_CRMS.includes(crm) && !S.ai && S.plan !== 'free' ? `<div class="note">${ic('spark', 'var(--vio)')}<span>Gebruik je Claude of ChatGPT? Koppel het in stap ${stepNo('ai') - 2}; dan geeft je AI je klanten door en hoef je niet te exporteren.</span><button type="button" class="btn btn-s" data-act="step" data-v="${stepNo('ai')}">Naar stap ${stepNo('ai') - 2}</button></div>` : ''}`;
  return `<h1 id="st-h">Voeg je klanten toe</h1><p class="lead">Oud-klanten en open offertes zijn je warmste ingangen.${nm ? ` Met ${nm} gekoppeld hoef je meestal niets te exporteren.` : ''}</p>${sampleNote()}
    ${radios('crm', 'Waar staan je klanten nu?', crm, 'crm', Object.entries(CRM_STEPS).map(([k, v]) => ({ k, t: v[0], wide: k === 'geen' })), 'tiles')}
    ${pane ? `<div class="pane2" id="pane">${pane}</div>` : ''}`;
}

/* ------------------------------------------------------------------ stap 4: ideale klant */
const REG = ['Noord-Nederland', 'Groningen', 'Friesland', 'Drenthe', 'Overijssel', 'Gelderland', 'Flevoland', 'Utrecht', 'Noord-Holland', 'Zuid-Holland', 'Zeeland', 'Noord-Brabant', 'Limburg', 'Randstad', 'Nederland', 'België', 'Vlaanderen', 'Duitsland'];
const SECT = [['zakelijke dienstverlening', 'Zakelijke dienstverlening'], ['b2b', 'B2B'], ['industrie', 'Industrie'], ['bouw', 'Bouw'], ['logistiek', 'Logistiek'], ['transport', 'Transport'], ['zorg', 'Zorg'], ['software', 'Software'], ['saas', 'SaaS'], ['ict', 'ICT'], [' it', 'IT'], ['energie', 'Energie'], ['retail', 'Retail'], ['e-commerce', 'E-commerce'], ['webshop', 'E-commerce'], ['onderwijs', 'Onderwijs'], ['overheid', 'Overheid'], ['financ', 'Financiële dienstverlening'], ['accountan', 'Accountancy'], ['horeca', 'Horeca'], ['agr', 'Agrarisch'], ['techniek', 'Techniek'], ['installatie', 'Installatie'], ['food', 'Food'], ['vastgoed', 'Vastgoed']];
const SIG = [['groei', 'Groeiplannen'], ['vacature', 'Vacatures'], ['aanbested', 'Aanbestedingen'], ['marketingafdeling', 'Eigen marketingafdeling'], ['nieuwe vestiging', 'Nieuwe vestiging'], ['investering', 'Investeringen'], ['overname', 'Overnames']];
function makeCrit(text) {
  const t = ' ' + text.toLowerCase() + ' ';
  const out = [];
  const add = (g, v) => { if (!out.some(c => c.g === g && c.v === v)) out.push({ g, v, on: true }); };
  for (const s of SECT) if (t.includes(s[0])) add('Sector', s[1]);
  for (const r of REG) if (t.includes(r.toLowerCase())) add('Regio', r);
  const m = t.match(/(\d+)\s*(?:tot|-|à|en)\s*(\d+)\s*(medewerkers|werknemers|mensen|fte|werkzame)/);
  if (m) add('Grootte', `${m[1]} tot ${m[2]} werkzame personen`);
  else { const m2 = t.match(/(?:meer dan|vanaf|minimaal)\s*(\d+)\s*(medewerkers|werknemers|mensen|fte)/); if (m2) add('Grootte', `vanaf ${m2[1]} werkzame personen`); }
  for (const s of SIG) if (t.includes(s[0])) add('Signalen', s[1]);
  add('Uitsluiten', 'Bestaande klanten'); add('Uitsluiten', 'Concurrenten'); add('Uitsluiten', 'Eenmanszaken');
  return out;
}
/* bij opnieuw maken blijven jouw aan- en uitzetkeuzes staan */
function mergeCrit(fresh) { return fresh.map(c => { const old = S.icp.crit.find(o => o.g === c.g && o.v === c.v); return old ? Object.assign(c, { on: old.on }) : c; }); }
function dreamResult() {
  const s = latest();
  if (!S.dream.length) return '';
  if (!s) return `<div class="note">${ic('info', 'var(--vio)')}<span>Voeg je LinkedIn-export toe in stap 2; dan zie je hier meteen bij welke droomklanten je al iemand kent.</span></div>`;
  const map = companies(s);
  const hits = S.dream.map(d => [d, findCo(map, d)]).filter(x => x[1]);
  if (!hits.length) return `<div class="note">${ic('info', 'var(--vio)')}<span>Bij je droomklanten kennen we nog niemand uit je LinkedIn-netwerk. De netwerken van je collega's kunnen dat veranderen.</span></div>`;
  return `<div class="aha" aria-live="polite"><b>Bij ${nf(hits.length)} van je ${nf(S.dream.length)} droomklanten ken je al iemand</b>
    <div class="ppl">${hits.map(([d, f]) => `<span><b>${esc(f.name)}</b>${f.exact ? '' : ` <span class="muted">(lijkt op ${esc(d)})</span>`}: ${f.people.slice(0, 3).map(p => esc(p[1] + ' ' + p[2]) + (p[4] ? `, ${esc(p[4].toLowerCase())}` : '')).join(' · ')}${f.people.length > 3 ? ` en ${nf(f.people.length - 3)} meer` : ''}</span>`).join('')}</div>
    <span class="small muted">Gekoppeld op bedrijfsnaam. Zodra zo'n bedrijf je site bezoekt of iets nieuws doet, staat het in je mail.</span></div>`;
}
function stepIcp() {
  const groups = ['Sector', 'Regio', 'Grootte', 'Signalen', 'Uitsluiten'];
  const t = S.icp.text.trim(); const stale = S.icp.critFrom !== t && t.length >= 20;
  const crit = S.icp.crit.length ? `<div class="card"><div class="card-h"><span class="k">Je criteria · klik om er een aan of uit te zetten</span><button type="button" class="btn btn-g" data-act="crit-clear">Wis criteria</button></div><div class="crit">${groups.filter(g => S.icp.crit.some(c => c.g === g)).map(g => `<b>${g}</b><div class="chips">${S.icp.crit.map((c, i) => c.g === g ? `<button type="button" class="chip tog${c.on ? '' : ' off'}" data-act="crit" data-v="${i}" aria-pressed="${c.on}">${c.on ? ic('check', 'currentColor', 2.6) : ''}${esc(c.v)}</button>` : '').join('')}</div>`).join('')}</div>
    <span class="small muted">In de echte app maakt onze AI deze criteria. Hier: een eerste versie op basis van je woorden.</span></div>` : '';
  const s = latest(); let sugg = '';
  if (s) {
    const have = new Set(S.dream.map(d => normCo(d)));
    const top = [...companies(s).values()].filter(c => !have.has(normCo(c.name))).sort((a, b) => b.people.length - a.people.length).slice(0, 8);
    if (top.length) sugg = `<div class="sugg2"><span class="small muted">Uit je netwerk, waar je de meeste mensen kent:</span><div class="chips">${top.map(c => `<button type="button" class="chip add" data-act="sugg" data-v="${esc(c.name)}">+ ${esc(c.name)} <span class="muted num">${c.people.length}</span></button>`).join('')}</div></div>`;
  }
  return `<h1 id="st-h">Wie is je ideale klant?</h1><p class="lead">Eén of twee zinnen is genoeg. Daarna zie je meteen bij welke droomklanten je al iemand kent.</p>
    <div class="field"><label for="f-icp">Beschrijf je ideale klant</label><textarea class="input" id="f-icp" placeholder="Bijvoorbeeld: B2B-bedrijven met 10 tot 200 medewerkers in Noord-Nederland die willen groeien.">${esc(S.icp.text)}</textarea>
    ${U.err.icp ? `<span class="err" role="alert">${esc(U.err.icp)}</span>` : ''}
    <div class="btns">${!S.icp.crit.length || stale ? `<button type="button" class="btn btn-s" data-act="mkcrit">${ic('spark', 'currentColor')} ${S.icp.crit.length ? 'Werk mijn criteria bij' : 'Maak mijn criteria'}</button>` : ''}<button type="button" class="btn btn-g" data-act="icp-sample" ${t ? 'hidden' : ''}>Gebruik een voorbeeld</button></div></div>
    ${crit}
    <div class="field"><label for="f-dream">Je droomklanten</label><span class="hint">Bedrijven die je graag als klant zou hebben. Vijf tot twintig. Enter voegt toe.</span>
      ${S.dream.length ? `<div class="chips">${S.dream.map((d, i) => `<span class="chip">${esc(d)}<button type="button" class="chipx" data-act="undream" data-v="${i}" aria-label="Verwijder ${esc(d)}">${ic('x')}</button></span>`).join('')}</div>` : ''}
      <div class="btns"><input class="input" id="f-dream" value="${esc(U.dreamDraft || '')}" placeholder="Typ een bedrijfsnaam, of plak een lijst" style="flex:1 1 220px;width:auto"><button type="button" class="btn btn-s" data-act="dream">Voeg toe</button></div>${sugg}</div>
    ${dreamResult()}`;
}

/* ------------------------------------------------------------------ stap 5: collega's */
const ROLES = [{ k: 'Netwerklid', t: 'Netwerklid, gratis' }, { k: 'Gebruiker', t: 'Gebruiker' }];
const ROLE_WHY = { Netwerklid: 'Voegt alleen zijn netwerk toe. Gratis.', Gebruiker: 'Krijgt ook de kansenmail en de koppeling met Claude of ChatGPT.' };
function roleSeg(cur, act, idx) {
  if (S.plan === 'free') return `<span class="pill p-warm">Netwerklid · gratis</span>`;
  return `<div class="seg sm" role="radiogroup" aria-label="Rol">${ROLES.map(r => `<button type="button" role="radio" aria-checked="${cur === r.k}" data-act="${act}" data-v="${idx != null ? idx + ':' : ''}${r.k}">${r.k}</button>`).join('')}</div>`;
}
function teamUI() {
  const d = U.tm || (U.tm = { name: '', email: '', role: 'Netwerklid' });
  const me = S.account ? `<div class="tm"><span class="av">${esc(initials(S.account.name))}</span><span class="tmi">${esc(S.account.name)} <span class="muted small">(jij)</span></span><span class="tmr"><span class="pill p-net">Beheerder</span></span><span class="tmx"></span></div>` : '';
  return `<div class="team">${me}${S.team.map((t, i) => `<div class="tm"><span class="av">${esc(initials(t.name))}</span><span class="tmi"><b>${esc(t.name)}</b> <span class="muted small">${esc(t.email)}</span></span><span class="tmr">${roleSeg(t.role, 'tm-setrole', i)}</span>${U.confirm === 'tm:' + i ? `<span class="tmx confirm"><button type="button" class="btn btn-bad" data-act="del" data-v="tm:${i}">Verwijder</button><button type="button" class="btn btn-g" data-act="nodel">Annuleer</button></span>` : `<button type="button" class="btn btn-g tmx" data-act="ask-del" data-v="tm:${i}" aria-label="Verwijder ${esc(t.name)}">${ic('x')}</button>`}</div>`).join('')}</div>
    <div class="card alt"><b>Nodig iemand uit</b>
      <div class="tmform"><div class="field"><label for="f-tm-name">Naam</label><input class="input" id="f-tm-name" autocomplete="off" value="${esc(d.name)}"></div>
      <div class="field"><label for="f-tm-email">Werkmail</label><input class="input" id="f-tm-email" type="email" autocomplete="off" value="${esc(d.email)}"></div></div>
      ${S.plan === 'free' ? '' : `<div class="field"><span class="lab">Rol</span>${roleSeg(d.role, 'tm-role')}<span class="hint">${ROLE_WHY[d.role]}</span></div>`}
      ${U.err.tm ? `<span class="err" role="alert">${esc(U.err.tm)}</span>` : ''}
      <div><button type="button" class="btn btn-s" data-act="addtm">Nodig uit</button></div></div>`;
}
function stepTeam() {
  const p = plan(); const users = 1 + S.team.filter(t => t.role === 'Gebruiker').length;
  return `<h1 id="st-h">Nodig je collega's uit</h1>
    <p class="lead">Elke collega die zijn netwerk toevoegt, geeft je meer ingangen. Collega's zien wie een ingang heeft, niet elkaars contacten.</p>
    ${teamUI()}
    ${S.plan !== 'free' && users > p.users ? `<p class="small muted">Je hebt nu ${users} gebruikers; in ${esc(p.name)} zitten er ${p.users}. Elke extra gebruiker kost na je proef ${euro(PRICE_EXTRA)} per maand. Netwerkleden zijn gratis.</p>` : ''}
    <p class="small muted">Uitnodigingen gaan de deur uit zodra de app live is.</p>`;
}

/* ------------------------------------------------------------------ stap: Instagram en Facebook
   Een eigen, officiële koppeling met Meta (inloggen bij Meta zelf). We lezen alleen wie en wanneer, nooit de inhoud.
   Volgers geeft Meta niet via een koppeling; die komen uit de eigen Instagram-export van de klant. */
function stepMeta() {
  const m = S.meta; const f = m.followers;
  const err = U.err.ig ? `<span class="err" role="alert">${esc(U.err.ig)}</span>` : '';
  const reads = [['mail', 'Wie je een bericht stuurt, en wanneer', 'Op Instagram en Facebook. Nooit de inhoud.'], ['users', 'Wie op je posts reageert of je noemt', 'Zo zie je welke bekenden je al volgen en meedoen.'], ['target', 'Leads uit je Meta-advertenties', 'Naam, bedrijf en mailadres, en of je er al iemand kent.']];
  return `<h1 id="st-h">Koppel Instagram en Facebook</h1>
    <p class="lead">Zo zien we wie met je bedrijf praat op Instagram en Facebook, en leggen we dat naast je netwerk. Stuurt iemand van Northpeak je een bericht, dan weet je dat je er Peter al kent.</p>
    ${m.connected ? `<div class="success">${ic('check', 'var(--ok)', 2.4)}<div><b>Gekoppeld met Meta</b><span class="small muted">Sinds ${fmtDate(m.at)}. We lezen alleen; we plaatsen en versturen niets.</span></div>${confirmBtn('meta', 'Ontkoppel', 'Ja, ontkoppel')}</div>`
      : `<div class="bigact"><button type="button" class="btn btn-p big" data-act="meta-connect">${ic('image', 'currentColor')} Koppel met Meta</button><span class="small muted">Je logt in bij Meta zelf en kiest je Instagram-account en Facebook-pagina. Wij lezen alleen.</span></div>`}
    <div class="card"><span class="k">Wat we lezen</span>${reads.map(([i, t, s]) => `<span class="klr">${ic(i, 'var(--vio)')}<span class="kt"><b>${t}</b><span class="small muted">${s}</span></span></span>`).join('')}</div>
    <div class="field"><span class="lab">Je volgers op Instagram</span>
      ${f ? `<div class="frow">${ic('image')}<span class="ft"><b>${esc(f.file)}</b><small>${plural(f.rows.length, 'volger', 'volgers')} · toegevoegd op ${fmtDate(f.date)}</small></span><span class="btns">${confirmBtn('ig', 'Verwijder')}</span></div>`
        : `<span class="hint">Meta geeft je volgers niet via een koppeling. Vraag ze op Instagram aan: Instellingen, Accountcentrum, Je gegevens downloaden, kies Volgers en volgend en het formaat JSON. Sleep de zip daarna hierheen.</span>
        ${dropZone('ig', 'Zip van Instagram', 'Uitpakken hoeft niet. We bewaren alleen de gebruikersnamen en de datum.', '.zip,.json')}`}${err}</div>
    <p class="small muted">Concept: het koppelen met Meta is hier nagebootst. Je volgersbestand lezen we wel echt, in je browser.</p>`;
}

/* ------------------------------------------------------------------ stap: Claude of ChatGPT
   Eerst deze vraag, want met een koppeling hoeft de klant bij Klanten niets te exporteren. */
function stepAi() {
  const head = `<h1 id="st-h">Gebruik je Claude of ChatGPT?</h1><p class="lead">Koppel het, dan geeft je AI je klanten uit je CRM aan ons door. Exporteren hoeft dan niet. Zonder werkt alles ook.</p>`;
  if (S.plan === 'free') return `${head}<div class="note">${ic('info', 'var(--vio)')}<span>De koppeling zit in Growth. Op Free voeg je je klanten in de volgende stap toe met een export.</span></div>
    <div><button type="button" class="btn btn-s" data-act="plan" data-v="growth">Probeer Growth ${trialDays()} dagen gratis</button></div>`;
  const a = S.ai; const nm = AI_NAME[a];
  const opts = [{ k: 'claude', i: 'spark', t: 'Ja, Claude', s: 'Werkt op alle abonnementen' }, { k: 'chatgpt', i: 'spark', t: 'Ja, ChatGPT', s: 'Op Business en Enterprise' }, { k: 'none', i: 'x', t: 'Nee, nu niet', s: 'Je klanten voeg je straks toe met een export' }];
  return `${head}${radios('ai', 'Wil je het koppelen?', a, 'ai', opts, 'cards')}
    ${nm ? `<div class="pane2" id="pane"><ol class="flow">
      <li><span class="fn">1</span><div class="fb2"><b>Voeg ${BRAND} toe aan ${nm}</b><span class="small muted">In ${nm}: Instellingen, Connectors, eigen connector toevoegen. Plak dit adres:</span><div class="codebox"><div class="code" id="mcpurl">${MCP_URL}</div><button type="button" class="btn btn-s" data-act="copy" data-v="mcpurl">${ic('copy')} Kopieer</button></div>
        ${checkRow('ai-linked', !!S.aiLinked, 'De connector staat erin', S.aiLinked ? `Mooi. In de volgende stap laat je ${nm} je klanten doorgeven.` : 'Vink aan als je hem hebt toegevoegd.')}</div></li></ol>
      <p class="small muted">Je AI geeft alleen naam, bedrijf, relatie en datum door; nooit de inhoud van mails. De connector gaat open als de app live is.</p></div>`
    : a === 'none' ? `<div class="note">${ic('info', 'var(--vio)')}<span>Prima. In de volgende stap voeg je je klanten toe met een export. Koppelen kan later altijd, in Bronnen.</span></div>` : ''}`;
}

/* ------------------------------------------------------------------ klaar */
function mailBlock() {
  ensureRhythm(); const p = plan();
  return `<div class="card"><span class="k">Je kansenmail</span>
    <div class="mailrow"><div class="field"><span class="lab" id="rg-rh">Hoe vaak?</span><div class="seg" role="radiogroup" aria-labelledby="rg-rh">${p.rhythms.map(r => `<button type="button" role="radio" aria-checked="${S.mail.rhythm === r}" data-act="rhythm" data-v="${esc(r)}">${r}</button>`).join('')}</div>${S.plan === 'free' ? '<span class="hint">Op Free: 1 kans per week. Growth kan elke werkdag.</span>' : ''}</div>
    <div class="field" style="max-width:200px"><label for="f-time">Hoe laat?</label><select class="input" id="f-time">${['07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00'].map(t => `<option ${S.mail.time === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div></div></div>`;
}
function viewKlaar() {
  const n = strength(); const name = S.account ? firstName(S.account.name) : '';
  const have = SOURCES.filter(s => stepStatus(s.id) === 'done' && srcScore(s.id) > 0);
  const tp = tips(); const empty = n < 22;
  ensureRhythm();
  return `<div class="ob">${obHeader('klaar', true)}
    <section class="klaar" aria-labelledby="k-h">
      <div class="kl-top"><span class="kl-orb${empty ? ' dim' : ''}" aria-hidden="true">${ic(empty ? 'spark' : 'check', '#FFFFFF', 2.6)}</span>
        <div><h1 id="k-h">${empty ? `Je account staat${name ? ', ' + esc(name) : ''}.` : `Je start staat${name ? ', ' + esc(name) : ''}.`}</h1>
        <p class="lead">${empty ? 'Je kansen worden pas goed met bronnen. Begin met je website of LinkedIn; dat kost een paar minuten.' : S.mail.paused ? 'Je kansenmail staat uit.' : `Je eerste mail komt de volgende werkdag om ${esc(S.mail.time)}. Daarna ${esc(S.mail.rhythm.toLowerCase())}.`}${S.trialStart ? ` Je proef loopt tot ${trialEnd()}.` : ''}</p></div></div>
      <div class="meter big"><div class="mrow"><span>Sterkte van je bronnen</span><b class="num">${n}<small>/100</small> · ${strengthLabel(n)}</b></div><div class="bar"><i style="width:${n}%"></i></div></div>
      <div class="kl-cols">
        <div class="card"><span class="k">Wat we al hebben</span>${have.length ? have.map(s => `<span class="klr">${ic('check', 'var(--ok)', 2.4)}<span class="kt"><b>${esc(s.t)}</b><span class="small muted">${esc(s.why)}</span></span></span>`).join('') : '<span class="small muted">Nog geen bron gekoppeld.</span>'}
          ${seenNow().length ? `<span class="small">${esc(seenNow().join(' · '))}</span>` : ''}</div>
        <div class="card"><span class="k">${tp.length ? 'Maak het nog sterker' : 'Alles staat'}</span>${tp.length ? tp.map(x => `<span class="klr">${ic(x.s.icon, 'var(--mu)')}<span class="kt"><b>${esc(x.t)}</b><span class="small muted">+${x.pts} sterkte</span></span><button type="button" class="btn btn-s" data-act="edit" data-v="${stepNo(x.s.id)}" data-ret="klaar">Nu doen</button></span>`).join('') : '<span class="small muted">Je bronnen zijn compleet. Wij doen de rest.</span>'}</div>
      </div>
      ${mailBlock()}
      <div class="btns"><button type="button" class="btn btn-s" data-act="step" data-v="${STEPS.length}">Terug</button><button type="button" class="btn btn-p big" data-act="finish">Naar je overzicht</button></div>
    </section>${foot()}</div>`;
}
function activationCard() {
  const tp = tips(); if (!tp.length) return '';
  const n = strength(); const left = DATA_STEPS.filter(s => !isReady(s.id)).length;
  return `<section class="act" aria-labelledby="h-act"><div class="act-h"><div><h2 id="h-act">${S.finished ? 'Maak je netwerk sterker' : `Maak je start af · nog ${left} ${left === 1 ? 'stap' : 'stappen'}`}</h2><span class="small muted">Hoe meer bronnen, hoe meer kansen in je mail.</span></div><b class="num">${n}<small>/100</small></b></div>
    <div class="bar"><i style="width:${n}%"></i></div>
    <div class="act-l">${tp.slice(0, 3).map(x => `<button type="button" class="act-i" data-act="${S.finished ? 'edit' : 'resume'}" data-v="${stepNo(x.s.id)}" data-ret="vandaag"><span class="si">${ic(x.s.icon)}</span><span><b>${esc(x.t)}</b><small>${esc(x.s.why)}</small></span><span class="sp num">+${x.pts}</span></button>`).join('')}</div></section>`;
}
function priceSum() {
  const p = plan(); const users = 1 + S.team.filter(t => t.role === 'Gebruiker').length; const extra = Math.max(0, users - p.users);
  if (S.plan === 'free') return `<div class="sum"><span><b class="num">€ 0</b> · Free, 1 gebruiker</span><span class="muted">Collega's kunnen hun netwerk gratis toevoegen</span></div>`;
  return `<div class="sum"><span><b class="num">${euro(p.price + extra * PRICE_EXTRA)}</b> per maand, bij jaarbetaling</span><span>${esc(p.name)}, ${p.users} gebruikers${extra ? ` + ${extra} × ${euro(PRICE_EXTRA)}` : ''}</span><span class="muted">${S.plan === 'growth' && trialLeft() !== 0 ? `Eerst ${trialDays()} dagen gratis · ` : ''}netwerkleden gratis</span></div>`;
}

/* ------------------------------------------------------------------ app */
function sideNav(page) {
  const items = [['vandaag', 'home', 'Vandaag'], ['netwerk', 'net', 'Netwerk'], ['bronnen', 'plug', 'Bronnen'], ['partners', 'tag', 'Verdien mee'], ['instellingen', 'gear', 'Instellingen']];
  const nav = items.map(([k, i, t]) => `<a class="it" href="#${k}" ${page === k ? 'aria-current="page"' : ''}>${ic(i)}${t}</a>`).join('');
  const n = strength(); const left = DATA_STEPS.filter(s => !isReady(s.id)); const fo = firstOpen();
  const setup = left.length ? `<div class="setup"><b>Je start: ${doneCount()} van ${DATA_STEPS.length} klaar</b><div class="bar"><i style="width:${Math.round(doneCount() / DATA_STEPS.length * 100)}%"></i></div><span class="small muted">Sterkte van je bronnen: <span class="num">${n}</span>/100</span><button type="button" class="btn btn-s" data-act="${S.finished ? 'edit' : 'resume'}" data-v="${fo <= STEPS.length ? fo : stepNo(left[0].id)}" data-ret="${page}">Ga verder met je start</button></div>` : '';
  const a = S.account || {};
  return `<nav class="side" aria-label="App"><a class="brand" href="#vandaag">${LOGO}<span>${WORD}</span></a>${nav}${setup}
    <div class="me"><span class="av">${esc(initials(a.name))}</span><div style="min-width:0"><b style="font-size:13px;display:block">${esc(a.name)}</b><span class="muted small">${esc(a.company)} · ${S.plan ? esc(plan().name) : 'nog geen pakket'}</span></div></div></nav>`;
}
function banner() {
  if (S.sample) return `<div class="banner"><span><b>Je bekijkt voorbeeldgegevens.</b> Voeg je eigen export toe, of wis ze in Bronnen.</span><a class="btn btn-s" href="#bronnen">Naar Bronnen</a></div>`;
  if (S.plan === 'free') return `<div class="banner"><span><b>Free:</b> je beste kans van de week. Growth laat elke werkdag alle kansen en je oude relaties zien.</span><button type="button" class="btn btn-p" data-act="plan" data-v="growth">Probeer ${trialDays()} dagen gratis</button></div>`;
  if (S.plan === 'growth') {
    const l = trialLeft();
    if (l === null) return `<div class="banner"><span><b>Growth-proef:</b> je ${trialDays()} dagen beginnen als je je eerste bron toevoegt.</span></div>`;
    return `<div class="banner"><span><b>Growth-proef:</b> nog ${plural(l, 'dag', 'dagen')} gratis. Daarna ${euro(PLANS.growth.price)} per maand, of gratis verder met Free.</span><a class="btn btn-s" href="#instellingen">Bekijk je pakket</a></div>`;
  }
  return '';
}
function insCard(x) {
  const ppl = list => list.slice(0, 3).map(p => `<span><b>${esc(p[1] + ' ' + p[2])}</b>${p[4] ? `, ${esc(p[4])}` : ''}${p[5] ? ` · connectie sinds ${p[5].slice(0, 4)}` : ''}</span>`).join('');
  if (x.kind === 'rec') {
    const p = x.c.person;
    return `<div class="insc"><div class="top"><span class="pill p-rec">Reconnect</span><b>${esc(p[1] + ' ' + p[2])}</b><span class="muted small">nu bij ${esc(p[3])}</span></div>
      <div class="ppl"><span>Was ${esc(x.c.fromPos ? x.c.fromPos.toLowerCase() + ' bij ' : '')}${esc(x.c.from)} in je export van ${fmtDate(x.c.was)}. Nu ${esc(p[4] ? p[4].toLowerCase() + ' bij ' : '')}${esc(p[3])}.</span>
      ${p[5] ? `<span>Je kent ${esc(p[1])} sinds ${fmtDate(p[5])}.</span>` : ''}</div>
      <span class="src">Bron: je LinkedIn-exports van ${fmtDate(x.c.was)} en ${fmtDate(x.c.since)} · beide banen bewaard</span></div>`;
  }
  if (x.kind === 'dream') return `<div class="insc"><div class="top"><span class="pill p-net">Droomklant</span><b>${esc(x.f.name)}</b><span class="muted small">${plural(x.f.people.length, 'ingang', 'ingangen')}</span></div><div class="ppl">${ppl(x.f.people)}</div><span class="src">Bron: LinkedIn-export · gekoppeld op bedrijfsnaam${x.f.exact ? '' : ' (lijkt op ' + esc(x.dream) + ')'}</span></div>`;
  const lab = x.kind === 'oud' ? ['Oud-klant', 'p-ex', 'oud-klant'] : ['Open offerte', 'p-warm', 'offerte'];
  return `<div class="insc"><div class="top"><span class="pill ${lab[1]}">${lab[0]}</span><b>${esc(x.f.name)}</b><span class="muted small">${esc(x.r[1] ? 'contact in je CRM: ' + x.r[1] : '')}</span></div><div class="ppl">${ppl(x.f.people)}</div><span class="src">Bron: klantenbestand (${lab[2]}) en LinkedIn-export</span></div>`;
}
function exampleBlock() {
  const k = EX.find(e => e.id === U.sel) || EX[0];
  const rows = EX.map(e => `<button type="button" class="row" data-act="sel" data-v="${e.id}" aria-selected="${e.id === k.id}"><span class="mono" style="background:${e.c}">${e.m}</span><span style="min-width:0"><span class="n">${esc(e.n)}</span><span class="w">${esc(e.w)}</span></span><span class="pill ${e.t[1]}">${e.t[0]}</span></button>`).join('');
  const tl = k.tl ? `<div class="q"><span class="k">Jullie geschiedenis</span><ol class="tl">${k.tl.map(([y, t]) => `<li><span class="y">${y}</span><span class="d"></span><span class="t">${t}</span></li>`).join('')}</ol><span class="src">Nooit overschreven: elk feit met bron en datum</span></div>` : '';
  const fb = S.fb[k.id];
  return `<div class="today"><div class="list" role="listbox" aria-label="Voorbeeldkansen">${rows}</div>
    <article class="det" aria-live="polite"><div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap"><span class="mono" style="background:${k.c}">${k.m}</span><h3 style="font-size:20px">${esc(k.n)}</h3><span class="pill ${k.t[1]}" style="margin-left:auto">${k.t[0]}</span></div>
      <div class="q"><span class="k">Waarom past dit bedrijf bij jou?</span><span class="a">${esc(k.fit)}</span><span class="src">Bron: ${esc(k.fitSrc)}</span></div>
      <div class="q"><span class="k">Waarom nu?</span><span class="a">${esc(k.now)}</span><span class="src">Bron: ${esc(k.nowSrc)}</span></div>
      <div class="q"><span class="k">Wie ken je er?</span><span class="a">${esc(k.who)}</span><span class="src">Bron: ${esc(k.whoSrc)}</span></div>${tl}
      <div class="rules"><span class="k">Wat mag</span><span>${ic('check', 'var(--ok)', 2.2)}${esc(k.call)}</span><span>${k.mail ? ic('check', 'var(--ok)', 2.2) : ic('info', 'var(--mu)')}${esc(k.mailWhy)}</span></div>
      <div class="btns">${k.person ? `<button type="button" class="btn btn-p" data-act="call">${ic('phone', 'currentColor')} Bel ${esc(k.person)}</button><button type="button" class="btn btn-s" data-act="mailp" ${k.mail ? '' : 'disabled'} title="${esc(k.mailWhy)}">${ic('mail')} Mail ${esc(k.person)}</button>` : `<button type="button" class="btn btn-p" data-act="tender">Bekijk de aanbesteding</button>`}</div>
      <div><span class="k">Wat heb je ermee gedaan?</span><div class="fb" style="margin-top:6px">${['Relevant', 'Gesprek gepland', 'Offerte', 'Deal', 'Niet relevant'].map(f => `<button type="button" data-act="fb" data-v="${f}" aria-pressed="${fb === f}">${f}</button>`).join('')}</div></div>
    </article></div>`;
}
function pageVandaag() {
  const a = S.account; const ins = insights(); ensureRhythm();
  const s0 = latest();
  const mine = s0 || S.cust ? (ins.length ? `<div class="ins">${ins.slice(0, U.allIns ? 50 : 6).map(insCard).join('')}</div>${ins.length > 6 && !U.allIns ? `<div><button type="button" class="btn btn-g" data-act="allins">Toon alle ${nf(ins.length)}</button></div>` : ''}`
      : `<div class="empty"><b>${s0 ? `Je kent ${plural(s0.rows.length, 'mens', 'mensen')} bij ${plural(companies(s0).size, 'bedrijf', 'bedrijven')}.` : 'Je klanten staan erin.'}</b><span>Kies je droomklanten; dan zie je hier meteen bij welke je al iemand kent.</span><div class="btns"><button type="button" class="btn btn-p" data-act="edit" data-v="${stepNo('icp')}" data-ret="vandaag">Kies droomklanten</button>${s0 ? '<a class="btn btn-s" href="#netwerk">Bekijk je netwerk</a>' : ''}</div></div>`)
    : `<div class="empty"><b>Hier verschijnen je ingangen.</b><span>Voeg je LinkedIn-export of je klantenbestand toe. Dan zie je bij welke droomklanten, oud-klanten en open offertes je al iemand kent.</span><div class="btns"><button type="button" class="btn btn-p" data-act="edit" data-v="${stepNo('linkedin')}" data-ret="vandaag">Voeg je netwerk toe</button></div></div>`;
  return `<div><h1 class="hi">${greet()}, ${esc(firstName(a.name))}.</h1><p class="muted">${fmtDate(todayIso())} · ${S.mail.paused ? 'Je kansenmail staat uit.' : `Je mail komt ${esc(S.mail.rhythm.toLowerCase())} om ${esc(S.mail.time)}.`}</p></div>
    ${banner()}${activationCard()}
    <section class="sec" aria-labelledby="h-mine"><div class="sec-h"><h2 id="h-mine">Uit je eigen netwerk</h2><span class="small muted">Berekend in deze browser</span></div>
      ${mine}
      ${ins.length ? `<p class="small muted">Dit zijn ingangen, nog zonder signaal. Zodra de herkenning en de signalen live zijn, wordt een ingang een kans: met een reden om vandaag te bellen.</p>` : ''}</section>
    <section class="sec" aria-labelledby="h-ex"><div class="sec-h"><h2 id="h-ex">Zo ziet een kans eruit</h2><span class="pill p-new">Voorbeeld</span></div>${exampleBlock()}</section>`;
}
function pageNetwerk() {
  const s = latest();
  if (!s) return `<div><h1 class="hi">Je netwerk</h1></div><div class="empty"><b>Nog geen netwerk.</b><span>Voeg je LinkedIn-export toe. Dan zie je hier wie je kent, bij welke bedrijven, en hoe je netwerk door de jaren groeide.</span><div class="btns"><button type="button" class="btn btn-p" data-act="edit" data-v="${stepNo('linkedin')}" data-ret="netwerk">Voeg je export toe</button></div></div>`;
  const map = companies(s);
  const years = {}; for (const r of s.rows) if (r[5]) { const y = r[5].slice(0, 4); years[y] = (years[y] || 0) + 1; }
  const ys = Object.keys(years).sort(); const max = Math.max(1, ...Object.values(years));
  const chart = ys.length ? `<div class="card"><b>Je netwerk door de jaren</b><span class="small muted">Nieuwe connecties per jaar. Alles blijft bewaard.</span>
    <div class="scroll"><div style="min-width:${ys.length * 34}px"><div class="years" role="img" aria-label="Nieuwe connecties per jaar: ${ys.map(y => y + ' ' + years[y]).join(', ')}">${ys.map(y => `<div class="yr"><em>${years[y]}</em><i style="height:${Math.round(years[y] / max * 120)}px"></i></div>`).join('')}</div>
    <div class="ylab" aria-hidden="true">${ys.map(y => `<span>${y}</span>`).join('')}</div></div></div></div>` : '';
  const ch = changes();
  const chBlock = `<div class="card"><b>Nieuwe banen</b>${ch.length ? `<span class="small muted">Vergeleken: je exports van ${fmtDate(snaps()[snaps().length - 2].date)} en ${fmtDate(s.date)}. Beide banen blijven bewaard.</span>
      <div class="ppl">${ch.map(c => `<span><b>${esc(c.person[1] + ' ' + c.person[2])}</b>: ${esc(c.from)} → ${esc(c.person[3])}</span>`).join('')}</div>`
    : `<span class="small muted">${S.li.length < 2 ? 'Voeg over een maand een nieuwe export toe. Dan zie je hier wie van baan wisselde; de oude gegevens blijven bewaard.' : 'Geen baanwissels tussen je laatste twee exports.'}</span>`}</div>`;
  const q = normCo(U.q);
  const list = [...map.values()].filter(c => !q || normCo(c.name).includes(q) || c.people.some(p => (p[1] + ' ' + p[2]).toLowerCase().includes(U.q.toLowerCase())))
    .sort((a, b) => b.people.length - a.people.length || a.name.localeCompare(b.name)).slice(0, 80);
  const since = c => c.people.map(p => p[5]).filter(Boolean).sort()[0];
  const rows = list.map(c => { const k = normCo(c.name); const open = !!U.open[k]; return `<div class="co"><button type="button" data-act="co" data-v="${esc(k)}" aria-expanded="${open}"><b>${esc(c.name)}</b><span class="num">${nf(c.people.length)}</span><span class="num since">${since(c) ? since(c).slice(0, 4) : ''}</span>${ic('chev')}</button>
    ${open ? `<div class="peo">${c.people.map(p => { const h = jobHistory(p[0]); return `<span><b>${esc(p[1] + ' ' + p[2])}</b>${p[4] ? `, ${esc(p[4])}` : ''}${p[5] ? ` · connectie sinds ${fmtDate(p[5])}` : ''}${h.length > 1 ? ` · eerder: ${h.slice(0, -1).map(x => esc(x.co)).join(', ')}` : ''}</span>`; }).join('')}</div>` : ''}</div>`; }).join('');
  const yrs = ys.length ? ys[0] : '';
  return `<div><h1 class="hi">Je netwerk</h1><p class="muted">Je salesgeheugen. Uit je LinkedIn-export van ${fmtDate(s.date)}. ${S.li.length > 1 ? `${S.li.length} exports bewaard; nieuwe informatie overschrijft oude nooit.` : ''}</p></div>
    <div class="stats"><div class="stat"><span>Mensen</span><b>${nf(s.rows.length)}</b></div><div class="stat"><span>Bedrijven</span><b>${nf(map.size)}</b></div><div class="stat"><span>Netwerk sinds</span><b>${esc(yrs)}</b></div><div class="stat"><span>Nieuwe banen</span><b>${nf(ch.length)}</b></div></div>
    ${memBlock()}
    ${chart}${chBlock}
    <section class="sec" aria-labelledby="h-co"><div class="sec-h"><h2 id="h-co">Bedrijven</h2><span class="small muted">Gesorteerd op het aantal mensen dat je er kent</span></div>
      <div class="field" style="max-width:420px"><label for="f-q" class="sr">Zoek</label><input class="input" id="f-q" type="search" placeholder="Zoek een bedrijf of persoon" value="${esc(U.q)}"></div>
      <div><div class="cohead k"><span>Bedrijf</span><span>Mensen</span><span class="since">Sinds</span><span></span></div>${rows || '<p class="muted" style="padding:12px 8px">Niets gevonden.</p>'}</div>
      ${map.size > 80 && !q ? `<p class="small muted">De 80 bedrijven waar je de meeste mensen kent. Zoek om de rest te vinden.</p>` : ''}</section>
    <p class="small muted">Je ziet alleen je eigen netwerk. Je collega's zien bij een bedrijf dat jij er een ingang hebt, niet je contactenlijst.</p>`;
}
/* ------------------------------------------------------------------ salesgeheugen: alles wat je over één bedrijf weet, op datum */
const MCLS = { klant: 'klant', oud: 'oud-klant', offerte: 'offerte', prospect: 'prospect', overig: 'in je klantenbestand' };
function allCompanies() {
  const m = new Map();
  for (const s of snaps()) for (const r of s.rows) { const k = normCo(r[3]); if (k && !m.has(k)) m.set(k, { name: r[3], people: [] }); }
  if (S.cust) for (const r of S.cust.rows) { const k = normCo(r[0]); if (k && !m.has(k)) m.set(k, { name: r[0], people: [] }); }
  return m;
}
function custFor(k) { return S.cust ? S.cust.rows.filter(r => normCo(r[0]) === k) : []; }
function memory(q) {
  const hit = findCo(allCompanies(), q); if (!hit) return null;
  const k = normCo(hit.name); const ss = snaps(); const last = ss[ss.length - 1];
  const seen = new Map();
  for (const s of ss) for (const r of s.rows) if (normCo(r[3]) === k && !seen.has(r[0])) seen.set(r[0], r);
  const ev = []; const now = []; const gone = [];
  for (const [pk, r] of seen) {
    const name = r[1] + ' ' + r[2]; const h = jobHistory(pk);
    const cur = last ? last.rows.find(x => x[0] === pk) : null;
    const i = h.findIndex(x => normCo(x.co) === k);
    if (r[5]) ev.push({ d: r[5], src: 'LinkedIn', t: `Connectie met <b>${esc(name)}</b>${i > 0 ? `, toen ${h[0].pos ? esc(h[0].pos) + ' ' : ''}bij ${esc(h[0].co)}` : r[4] ? `, ${esc(r[4])}` : ''}` });
    if (i > 0) { const prev = h[i - 1]; const pc = custFor(normCo(prev.co))[0]; ev.push({ d: h[i].date, src: 'LinkedIn-export', t: `<b>${esc(name)}</b> werkt hier nu, eerder bij ${esc(prev.co)}${pc ? ` (je ${MCLS[pc[3]]})` : ''}` }); }
    if (cur && normCo(cur[3]) === k) now.push({ name, pos: cur[4], from: i > 0 ? h[i - 1].co : '' });
    else if (cur) { const nx = h[i + 1]; ev.push({ d: nx ? nx.date : last.date, src: 'LinkedIn-export', t: `<b>${esc(name)}</b> vertrok naar ${esc(cur[3])}. Jullie relatie blijft bewaard` }); gone.push({ name, to: cur[3] }); }
  }
  for (const r of custFor(k)) ev.push({ d: S.cust.date, src: 'Klantenbestand', t: `In je klantenbestand als <b>${esc(MCLS[r[3]])}</b>${r[4] && normCo(r[4]) !== normCo(MCLS[r[3]]) ? ` (“${esc(r[4])}”)` : ''}${r[1] ? `, contact ${esc(r[1])}` : ''}` });
  const dreams = S.dream.length ? S.dream : (S.sample && S.sampleDream) || [];
  const dream = dreams.some(d => normCo(d) === k || (normCo(d).length >= 4 && (normCo(d).includes(k) || k.includes(normCo(d)))));
  ev.sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : 0));
  return { name: hit.name, exact: hit.exact, ev, now, gone, cust: custFor(k)[0] || null, dream };
}
function memWhy(m) {
  const from = m.now.find(p => p.from && custFor(normCo(p.from)).some(r => r[3] === 'klant' || r[3] === 'oud'));
  if (from) return `${esc(from.name)} kent jullie waarschijnlijk van ${esc(from.from)}. Een warme ingang.`;
  if (m.cust && m.cust[3] === 'oud') return 'Oud-klant. Een nee van toen kan nu een ja zijn.';
  if (m.cust && m.cust[3] === 'offerte') return 'Er lag hier een offerte. Kijk of het moment nu beter is.';
  if (m.now.length) return `Je kent hier ${plural(m.now.length, 'mens', 'mensen')}. Begin bij wie je het langst kent.`;
  if (m.gone.length) return 'Wie je hier kende, werkt er niet meer. Je kent ze nog wel, bij hun nieuwe werkgever.';
  return '';
}
function memBlock() {
  const q = (U.mem || '').trim(); const m = q ? memory(q) : null;
  const dreams = (S.dream.length ? S.dream : (S.sample && S.sampleDream) || []).slice(0, 4);
  const sugg = dreams.length ? `<div class="chips mchips"><span class="small muted">Probeer:</span>${dreams.map(d => `<button type="button" class="chip" data-act="mem" data-v="${esc(d)}">${esc(d)}</button>`).join('')}</div>` : '';
  let res = '';
  if (q && !m) res = `<div class="card mres" role="status"><b>Niets gevonden voor “${esc(q)}”</b><span class="small muted">Niet in je LinkedIn-exports en niet in je klantenbestand. Elke bron die je toevoegt, maakt je geheugen groter.</span></div>`;
  else if (m) {
    const why = memWhy(m);
    res = `<div class="card mres" role="status" aria-live="polite"><div class="mhead"><b>${esc(m.name)}</b>${m.dream ? '<span class="tag">Droomklant</span>' : ''}${m.cust ? `<span class="tag">${esc(MCLS[m.cust[3]])}</span>` : ''}</div>
      ${!m.exact ? `<span class="small muted">Dichtstbijzijnde naam bij “${esc(q)}”.</span>` : ''}
      <div class="mstats"><span><b class="num">${nf(m.now.length)}</b> ken je er nu</span><span><b class="num">${nf(m.gone.length)}</b> werkten er eerder</span><span><b class="num">${nf(m.ev.length)}</b> momenten</span></div>
      ${why ? `<p class="mwhy">${ic('spark', 'var(--vio)')}<span>${why}</span></p>` : ''}
      ${m.ev.length ? `<ol class="mline">${m.ev.map(e => `<li><span class="md num">${e.d ? fmtDate(e.d) : ''}</span><span class="mt">${e.t}</span><span class="ms">${esc(e.src)}</span></li>`).join('')}</ol>` : '<span class="small muted">Nog geen momenten met een datum.</span>'}
    </div>`;
  }
  return `<section class="sec" aria-labelledby="h-mem"><div class="sec-h"><h2 id="h-mem">Vraag je geheugen</h2><span class="small muted">Alles wat je over één bedrijf weet, op datum. Nooit overschreven.</span></div>
    <form data-form="mem" class="mform" novalidate role="search"><label for="f-mem" class="sr">Wie kende ik bij</label><input class="input" id="f-mem" type="search" placeholder="Wie kende ik bij… (bijvoorbeeld een bedrijfsnaam)" value="${esc(U.mem || '')}"><button class="btn btn-p" type="submit">Zoek</button></form>
    ${sugg}${res}</section>`;
}
function confirmBtn(id, label, yes) {
  return U.confirm === id ? `<span class="confirm"><button type="button" class="btn btn-bad" data-act="del" data-v="${esc(id)}">${yes || (label && /^Verwijder/.test(label) ? 'Ja, verwijder' : 'Ja, wis')}</button><button type="button" class="btn btn-g" data-act="nodel">Annuleer</button></span>`
    : `<button type="button" class="btn btn-g" data-act="ask-del" data-v="${esc(id)}">${label || 'Wis'}</button>`;
}
function pageBronnen() {
  const rows = [];
  for (const s of snaps()) rows.push([`LinkedIn-export`, `${esc(s.file)} · ${plural(s.rows.length, 'mens', 'mensen')}`, fmtDate(s.date), confirmBtn('li:' + s.id)]);
  if (custViaAi()) rows.push([`Klanten via ${AI_NAME[S.ai]}`, `${esc(CRM_STEPS[S.crm][0])}${S.custAiSent ? `, ververst elke werkdag om ${refreshTime()}; gaat open als de app live is` : ', nog geen opdracht gegeven'}`, '', `<button type="button" class="btn btn-g" data-act="edit" data-v="${stepNo('klanten')}" data-ret="bronnen">Wijzig</button>`]);
  if (S.cust) rows.push(['Klantenbestand', `${esc(S.cust.file)} · ${esc(custSummary())}`, fmtDate(S.cust.date), confirmBtn('cust')]);
  rows.push(['Instagram en Facebook', [S.meta.connected ? 'Gekoppeld met Meta' : 'Niet gekoppeld', S.meta.followers ? plural(S.meta.followers.rows.length, 'volger', 'volgers') : ''].filter(Boolean).join(' · '), S.meta.at ? fmtDate(S.meta.at) : '', `<button type="button" class="btn btn-g" data-act="edit" data-v="${stepNo('meta')}" data-ret="bronnen">Wijzig</button>`]);
  rows.push(['Website', S.site.verified ? 'Eigen script, we zien je site' : S.site.who === 'own' ? `${esc((S.site.tool === 'Iets anders' ? S.site.toolOther : S.site.tool) || 'Eigen tool')}, koppeling bij de livegang` : S.site.who === 'bouwer' ? (S.site.builderSent ? 'Bij je webbouwer, nog niet gezien' : 'Nog niet naar je webbouwer gestuurd') : S.site.who ? 'Eigen script, nog niet gezien' : 'Nog niet geplaatst', S.site.verifiedAt ? fmtDate(S.site.verifiedAt.slice(0, 10)) : '', `<button type="button" class="btn btn-g" data-act="edit" data-v="${stepNo('site')}" data-ret="bronnen">${S.site.who && S.site.who !== 'own' ? 'Toon je script' : 'Wijzig'}</button>`]);
  rows.push(['Claude of ChatGPT', S.plan === 'free' ? 'Zit in Growth' : S.ai === 'claude' ? 'Claude, connector gaat open bij de livegang' : S.ai === 'chatgpt' ? 'ChatGPT, connector gaat open bij de livegang' : 'Niet gekoppeld; alles werkt ook zonder', '', `<button type="button" class="btn btn-g" data-act="edit" data-v="${stepNo('ai')}" data-ret="bronnen">Wijzig</button>`]);
  return `<div><h1 class="hi">Bronnen</h1><p class="muted">Per bron wat erin zit en hoe vers het is. Elke bron kun je wissen; wat eruit volgde gaat mee.</p></div>
    <div class="scroll"><table class="tbl"><thead><tr><th>Bron</th><th>Inhoud</th><th>Datum</th><th class="r"><span class="sr">Actie</span></th></tr></thead><tbody>${rows.map(r => `<tr><td><b>${r[0]}</b></td><td>${r[1]}</td><td class="num">${r[2]}</td><td class="r">${r[3]}</td></tr>`).join('')}</tbody></table></div>
    ${U.err.li ? `<span class="err">${esc(U.err.li)}</span>` : ''}${U.err.cust ? `<span class="err">${esc(U.err.cust)}</span>` : ''}
    ${U.custDraft ? mappingUI() : ''}
    <div class="btns">${fileInput('li', '.csv,.zip')}<label class="btn btn-s" for="f-li">${ic('up')} Nieuwe LinkedIn-export</label>
      ${fileInput('cust', '.csv,.txt')}<label class="btn btn-s" for="f-cust">${ic('up')} ${S.cust ? 'Vervang klantenbestand' : 'Klantenbestand toevoegen'}</label>
      ${S.sample ? confirmBtn('sample', 'Wis de voorbeeldgegevens') : ''}</div>
    <div class="note">${ic('lock', 'var(--vio)')}<span>In dit concept staat alles alleen in deze browser${storeOk ? '' : ' (en de browser bewaart het niet; na verversen is het weg)'}. In de echte app staat het in de EU, per klant gescheiden, en zie je hier ook wat je AI via de koppeling doorgaf.</span></div>`;
}
function pageInstellingen() {
  ensureRhythm();
  const p = plan(); const l = trialLeft();
  const planCard = S.plan === 'free'
    ? `<div class="card"><b>Free</b><span>1 kans per week, 1 gebruiker, netwerkgeheugen tot 1.000 contacten.</span><div class="btns"><button type="button" class="btn btn-p" data-act="plan" data-v="growth">Probeer Growth ${trialDays()} dagen gratis</button></div></div>`
    : `<div class="card"><b>${esc(p.name)}${S.plan === 'growth' && l !== null ? ' · proef' : ''}</b><span>${S.plan === 'growth' && l !== null ? `Nog ${plural(l, 'dag', 'dagen')} gratis. Daarna ` : ''}${euro(p.price)} per maand bij jaarbetaling (per maand betalen: ${euro(p.price + MONTHLY_EXTRA)}). ${p.users} gebruikers, ${p.recog} herkende bedrijven per maand. Extra gebruiker ${euro(PRICE_EXTRA)}.</span>
      <div class="btns"><button type="button" class="btn btn-p" data-act="pay">Kies ${esc(p.name)}</button>${confirmBtn('free', 'Ga naar Free', 'Ja, ga naar Free')}</div>${U.confirm === 'free' ? `<span class="small">Op Free krijg je 1 kans per week. ${S.team.some(m => m.role === 'Gebruiker') ? "Je collega's met de rol Gebruiker worden netwerklid; terug naar Growth zet ze weer terug." : ''}</span>` : ''}<span class="small muted">Starter en Pro kies je hier zodra betalen live is.</span></div>`;
  const paused = S.mail.paused;
  return `<div><h1 class="hi">Instellingen</h1></div>
    <section class="sec" aria-labelledby="h-acc"><h2 id="h-acc" style="font-size:18px">Account</h2><form data-form="account" novalidate class="sec">${accountFields(S.account)}<div><button class="btn btn-s" type="submit">Bewaar</button></div></form></section>
    <section class="sec" aria-labelledby="h-plan"><h2 id="h-plan" style="font-size:18px">Pakket</h2>${planCard}</section>
    <section class="sec" aria-labelledby="h-mail"><h2 id="h-mail" style="font-size:18px">Kansenmail</h2>
      <div class="field"><span class="lab" id="rg-rh2">Ritme</span><div class="seg" role="radiogroup" aria-labelledby="rg-rh2">${p.rhythms.map(r => `<button type="button" role="radio" data-act="rhythm" data-v="${esc(r)}" aria-checked="${S.mail.rhythm === r}">${r}</button>`).join('')}</div></div>
      <div class="field" style="max-width:220px"><label for="f-time">Hoe laat?</label><select class="input" id="f-time">${['07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00'].map(t => `<option ${S.mail.time === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
      <div class="card"><b>${paused ? 'Je bent afgemeld voor de kansenmail' : 'De kansenmail staat aan'}</b><span class="small">${paused ? (S.plan === 'free' ? 'Ook het zoeken staat stil: we doen geen herkenning en geen AI-onderzoek meer. Je netwerk blijft bewaard.' : 'Je abonnement en de koppeling met Claude of ChatGPT lopen door.') : (S.plan === 'free' ? 'Meld je je af, dan stopt ook het zoeken. Je netwerk blijft bewaard.' : 'Meld je je af, dan stopt alleen de mail.')}</span>
        <div><button type="button" class="btn btn-s" data-act="pause">${paused ? 'Zet de mail weer aan' : 'Afmelden voor de mail'}</button></div></div></section>
    <section class="sec" aria-labelledby="h-team"><h2 id="h-team" style="font-size:18px">Team</h2>${teamUI()}</section>
    ${agencySection()}
    <section class="sec" aria-labelledby="h-data"><h2 id="h-data" style="font-size:18px">Je gegevens</h2>
      <div class="card"><b>Alles wissen</b><span class="small">Wist je account, je netwerk en je bestanden uit deze browser. Dit kun je niet terugdraaien.</span><div>${confirmBtn('all', 'Wis alles')}</div></div></section>`;
}
/* ------------------------------------------------------------------ verdien mee: partners en verwijzers
   Een commissie geeft geen toegang tot gegevens van klanten. Commissies en uitbetalingen komen straks uit Stripe. */
function partnerCode() { return ((S.account && S.account.company) || 'PARTNER').toUpperCase().normalize('NFD').replace(/[^A-Z0-9]/g, '').slice(0, 10) || 'PARTNER'; }
function refLink(code) { return `${SITE}/?ref=${code}`; }
const EXP = { clicks: 184, signups: 9, trials: 6, paying: 3, fixed: 71.40, paid: 214.20,
  clients: [['Vela Energy', 'Growth', 'betaalt', 35.70], ['Hesselink Bouw', 'Growth', 'betaalt', 35.70], ['Duinkerk Zorg', 'Starter', 'betaalt', 14.70], ['Corvus Health', 'Growth', 'proef', 0]] };
function money(v) { return '€ ' + Number(v).toLocaleString('nl-NL', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }); }
function pagePartners() {
  const pt = S.partner; const g = PLANS.growth;
  const head = `<div><h1 class="hi">Verdien mee</h1><p class="muted">Breng klanten aan en verdien elke maand een deel van hun abonnement.</p></div>`
    + (!S.plan && pt ? `<div class="banner"><span><b>Zelf gebruiken?</b> ${pt.type === 'agency' ? 'Als partner krijg je Growth gratis voor je eigen bureau.' : `Kies Free, of probeer Growth ${trialDays()} dagen gratis.`}</span><a class="btn btn-s" href="#start-2">Kies je pakket</a></div>` : '');
  if (!pt) {
    const pick = U.partnerPick || U.pendingPartner || 'agency';
    const card = (k, name, pct, sub, items) => `<button type="button" class="pcard${pick === k ? ' sel' : ''}" role="radio" aria-checked="${pick === k}" data-act="partner-pick" data-v="${k}"><span class="pc-h"><b>${name}</b><span class="rdot" aria-hidden="true"></span></span><span class="pc-p num">${pct}%</span><span class="small muted">${sub}</span><span class="pc-l">${items.map(i => `<span>${ic('check', 'var(--ok)', 2.4)}${i}</span>`).join('')}</span></button>`;
    return `${head}
      <div class="pcards" role="radiogroup" aria-label="Kies hoe je meedoet">
        ${card('agency', 'Partner', PARTNER.agencyPct, 'van wat je klant betaalt, zolang hij klant blijft en jij hem begeleidt', ['Vanaf je eerste klant', `Gratis Growth voor je eigen bureau`, `Je klanten proberen Growth ${PARTNER.clientTrialDays} dagen gratis`, 'Per klant: commissie of korting voor je klant'])}
        ${card('affiliate', 'Verwijzer', PARTNER.affiliatePct, `van wat je klant betaalt, de eerste ${PARTNER.affiliateMonths} maanden`, ['Een eigen link en code', `Een verwijzing telt ${PARTNER.windowDays} dagen`, 'Geen klantbeheer'])}
      </div>
      <div class="card"><b>Meld je aan als ${pick === 'agency' ? 'partner' : 'verwijzer'}</b>
        <div class="grid2"><div class="field"><label for="f-p-co">Bedrijf</label><input class="input" id="f-p-co" value="${esc((U.pdraft && U.pdraft.co) || (S.account && S.account.company) || '')}"></div>
        <div class="field"><label for="f-p-site">Website</label><input class="input" id="f-p-site" value="${esc((U.pdraft && U.pdraft.site) || (S.account && S.account.website) || '')}"></div></div>
        ${checkRow('partner-terms', !!U.partnerTerms, 'Ik ga akkoord met de partnervoorwaarden', `Commissie over wat de klant echt betaalt, zonder btw. Uitbetaling per maand vanaf ${money(PARTNER.payoutMin)}, na ${PARTNER.refundDays} dagen. Geen commissie op je eigen abonnement.`)}
        ${U.err.partner ? `<span class="err" role="alert">${esc(U.err.partner)}</span>` : ''}
        <div><button type="button" class="btn btn-p" data-act="partner-join">Meld je aan</button></div>
        <span class="small muted">Concept: je aanmelding wordt hier meteen goedgekeurd. Straks bekijken we elke aanvraag even.</span></div>
      <p class="small muted">Rekenvoorbeeld: tien klanten op Growth is als partner ${money(10 * g.price * PARTNER.agencyPct / 100)} per maand.</p>`;
  }
  const ex = U.partnerDemo ? EXP : { clicks: 0, signups: 0, trials: 0, paying: 0, fixed: 0, paid: 0, clients: [] };
  const choice = i => (pt.type === 'agency' && U.pchoice && U.pchoice[i]) || 'Commissie';
  const earned = ex.clients.reduce((t, c, i) => t + (c[2] === 'betaalt' && choice(i) === 'Commissie' ? c[3] : 0), 0);
  const link = refLink(pt.code);
  const clients = ex.clients.length ? `<div class="scroll"><table class="tbl ptbl"><thead><tr><th>Klant</th><th>Pakket</th><th>Stand</th><th class="r">Jouw deel per maand</th>${pt.type === 'agency' ? '<th>Commissie of korting</th>' : ''}</tr></thead><tbody>${ex.clients.map((c, i) => `<tr><td class="c-name"><b>${esc(c[0])}</b></td><td class="c-plan">${c[1]}</td><td class="c-stand"><span class="pill ${c[2] === 'betaalt' ? 'p-warm' : 'p-new'}">${c[2]}</span></td><td class="r num c-share">${!c[3] ? '-' : choice(i) === 'Korting' ? `<span class="small muted">korting voor klant</span> ${money(c[3])}` : money(c[3])}</td>${pt.type === 'agency' ? `<td class="c-choice"><div class="seg sm" role="radiogroup" aria-label="Commissie of korting voor ${esc(c[0])}">${['Commissie', 'Korting'].map(o => `<button type="button" role="radio" aria-checked="${choice(i) === o}" data-act="p-choice" data-v="${i}:${o}">${o}</button>`).join('')}</div></td>` : ''}</tr>`).join('')}</tbody></table></div>`
    : `<div class="empty"><b>Nog geen klanten via jou.</b><span>Deel je link of code${pt.type === 'agency' ? ', of nodig een klant uit' : ''}. Elke aanmelding zie je hier, met de stand: proef, betaalt of gestopt.</span></div>`;
  const inv = pt.type === 'agency' ? `<section class="sec" aria-labelledby="h-inv"><h2 id="h-inv" style="font-size:18px">Nodig een klant uit</h2>
      <div class="card"><div class="grid2"><div class="field"><label for="f-inv-name">Naam</label><input class="input" id="f-inv-name" value="${esc((U.inv && U.inv.name) || '')}"></div>
      <div class="field"><label for="f-inv-email">Werkmail</label><input class="input" id="f-inv-email" type="email" value="${esc((U.inv && U.inv.email) || '')}"></div></div>
      ${U.err.inv ? `<span class="err" role="alert">${esc(U.err.inv)}</span>` : ''}
      <div class="btns"><button type="button" class="btn btn-s" data-act="inv-send">${ic('mail', 'currentColor')} Open de uitnodiging in je mail</button></div>
      <span class="small muted">De uitnodiging staat klaar met je link erin. Jij verstuurt hem vanuit je eigen mail; wij versturen niets.</span>
      ${(pt.invites || []).length ? `<div class="ppl">${pt.invites.map(v => `<span><b>${esc(v.name)}</b> ${esc(v.email)} · uitgenodigd op ${fmtDate(v.at)}</span>`).join('')}</div>` : ''}</div></section>` : '';
  return `${head}
    <div class="banner"><span><b>${pt.type === 'agency' ? 'Partner' : 'Verwijzer'}</b> sinds ${fmtDate(pt.since)} · ${pt.type === 'agency' ? `${PARTNER.agencyPct}% zolang je klant blijft` : `${PARTNER.affiliatePct}% de eerste ${PARTNER.affiliateMonths} maanden`}${pt.type === 'agency' ? ' · gratis Growth voor je bureau' : ''}</span>
      <button type="button" class="btn btn-g" data-act="p-demo" aria-pressed="${!!U.partnerDemo}">${U.partnerDemo ? 'Verberg het voorbeeld' : 'Toon een voorbeeld'}</button></div>
    <section class="sec" aria-labelledby="h-link"><h2 id="h-link" style="font-size:18px">Je link en code</h2>
      <div class="codebox"><div class="code" id="p-link">${esc(link)}</div><button type="button" class="btn btn-p" data-act="copy" data-v="p-link">${ic('copy', 'currentColor')} Kopieer je link</button></div>
      <div class="codebox"><div class="code" id="p-code">${esc(pt.code)}</div><button type="button" class="btn btn-s" data-act="copy" data-v="p-code">${ic('copy')} Kopieer je code</button></div>
      <span class="small muted">Een klik telt ${PARTNER.windowDays} dagen. De code werkt ook als iemand cookies weigert. Klanten via jou proberen Growth ${PARTNER.clientTrialDays} dagen gratis.</span></section>
    <section class="sec" aria-labelledby="h-st"><h2 id="h-st" style="font-size:18px">Zo staat het${U.partnerDemo ? ' <span class="pill p-new">Voorbeeld</span>' : ''}</h2>
      <div class="stats pstats"><div class="stat"><span>Klikken</span><b>${nf(ex.clicks)}</b></div><div class="stat"><span>Aanmeldingen</span><b>${nf(ex.signups)}</b></div><div class="stat"><span>Proeven</span><b>${nf(ex.trials)}</b></div><div class="stat"><span>Betalende klanten</span><b>${nf(ex.paying)}</b></div></div>
      <div class="stats pstats"><div class="stat"><span>Te verdienen deze maand</span><b>${money(earned)}</b></div><div class="stat"><span>Vastgesteld</span><b>${money(ex.fixed)}</b></div><div class="stat"><span>Uitbetaald</span><b>${money(ex.paid)}</b></div><div class="stat"><span>Teruggedraaid</span><b>${money(0)}</b></div></div>
      <span class="small muted">Te verdienen wordt vastgesteld na ${PARTNER.refundDays} dagen; we betalen elke maand uit vanaf ${money(PARTNER.payoutMin)}. Wordt een betaling teruggedraaid, dan ook de commissie.</span></section>
    <section class="sec" aria-labelledby="h-cl"><h2 id="h-cl" style="font-size:18px">Je klanten</h2>${clients}</section>
    ${inv}
    <div class="note">${ic('shield', 'var(--ok)')}<span>Je ziet geen gegevens of kansen van je klanten. Wil een klant hulp, dan geeft hij je zelf toegang in zijn Instellingen, en hij kan die altijd intrekken.</span></div>
    <div>${confirmBtn('partner', 'Stop als ' + (pt.type === 'agency' ? 'partner' : 'verwijzer'), 'Ja, stop')}</div>`;
}
/* toegang voor een bureau: alleen als de klant die zelf geeft, per onderdeel, en altijd in te trekken */
function agencySection() {
  const list = S.agencyAccess || []; const d = U.ag || { email: '', scope: 'start' };
  const SC = { start: 'Helpen met je start en je bronnen', kansen: 'Ook je kansen inzien' };
  return `<section class="sec" aria-labelledby="h-ag"><h2 id="h-ag" style="font-size:18px">Je bureau</h2>
    ${S.referral ? (S.referral.ended ? `<p class="small muted">Aangebracht door partner <b>${esc(S.referral.code)}</b>. Je gaf op ${fmtDate(S.referral.ended)} aan dat dit bureau je niet meer begeleidt.</p>`
      : `<div class="frow"><p class="small" style="margin:0;flex:1 1 240px">Aangebracht door partner <b>${esc(S.referral.code)}</b>. Daarmee heeft die partner nog geen toegang tot je gegevens.</p>${confirmBtn('ref-end', 'Dit bureau begeleidt me niet meer', 'Ja, klopt')}</div>`) : ''}
    ${list.length ? `<div class="team">${list.map((a, i) => `<div class="tm"><span class="av">${esc(initials(a.email))}</span><span class="tmi"><b>${esc(a.email)}</b> <span class="muted small">${esc(SC[a.scope])} · sinds ${fmtDate(a.since)}</span></span><span class="tmr"></span>${U.confirm === 'ag:' + i ? `<span class="tmx confirm"><button type="button" class="btn btn-bad" data-act="del" data-v="ag:${i}">Trek in</button><button type="button" class="btn btn-g" data-act="nodel">Annuleer</button></span>` : `<button type="button" class="btn btn-g tmx" data-act="ask-del" data-v="ag:${i}">Trek in</button>`}</div>`).join('')}</div>` : '<p class="small muted">Geen bureau heeft toegang.</p>'}
    <div class="card alt"><b>Geef een bureau toegang</b>
      <div class="field"><label for="f-ag-email">Werkmail van je contact bij het bureau</label><input class="input" id="f-ag-email" type="email" value="${esc(d.email)}"></div>
      <div class="field"><span class="lab" id="rg-ag">Wat mag het bureau?</span><div class="seg" role="radiogroup" aria-labelledby="rg-ag">${Object.entries(SC).map(([k, t]) => `<button type="button" role="radio" aria-checked="${d.scope === k}" data-act="ag-scope" data-v="${k}">${t}</button>`).join('')}</div>
      <span class="hint">Je LinkedIn-, mail- en CRM-gegevens ziet een bureau nooit. Je kunt de toegang altijd intrekken.</span></div>
      ${U.err.ag ? `<span class="err" role="alert">${esc(U.err.ag)}</span>` : ''}
      <div><button type="button" class="btn btn-s" data-act="ag-add">Geef toegang</button></div></div>
    ${(S.accessLog || []).length ? `<details class="help"><summary>Wie had wanneer toegang</summary><div class="ppl">${S.accessLog.slice(-8).reverse().map(l => `<span>${fmtDate(l.at)}: ${esc(l.what)}</span>`).join('')}</div></details>` : ''}</section>`;
}
function viewApp(page) {
  const body = ({ vandaag: pageVandaag, netwerk: pageNetwerk, bronnen: pageBronnen, partners: pagePartners, instellingen: pageInstellingen })[page]();
  return `<div class="concept">${ic('lock', 'currentColor')}<span>Concept van de app. Alles wat je invoert blijft in deze browser; er gaat niets naar een server.</span>${designLink()}</div>
    <div class="shell">${sideNav(page)}<main class="main" id="main">${body}</main></div>`;
}

/* ------------------------------------------------------------------ bestanden verwerken */
async function readFile(file) {
  const buf = await file.arrayBuffer();
  const u8 = new Uint8Array(buf, 0, Math.min(4, buf.byteLength));
  const isZip = u8[0] === 0x50 && u8[1] === 0x4b;
  return { buf, isZip, text: isZip ? null : decode(buf) };
}
function decode(buf) {
  const t = new TextDecoder('utf-8', { fatal: false }).decode(buf);
  return t.includes('\uFFFD') ? new TextDecoder('windows-1252').decode(buf) : t;
}
async function addLinkedIn(file) {
  U.err.li = '';
  if (file.size > 25 * 1024 * 1024) { U.err.li = 'Dit bestand is groter dan 25 MB. Kies alleen Connections.csv.'; return render(); }
  try {
    const f = await readFile(file);
    let text = f.text;
    if (f.isZip) { text = await zipEntry(f.buf, n => /(^|\/)connections\.csv$/i.test(n)); if (!text) throw new Error('In deze zip staat geen Connections.csv. Vraag bij LinkedIn het archief met Connecties aan.'); }
    const rows = parseLinkedIn(text);
    if (!rows.length) throw new Error('In dit bestand staan geen connecties.');
    if (S.sample) clearSample();
    const sig = rr => rr.map(r => r[0] + '|' + normCo(r[3])).sort().join('\n');
    const sg = sig(rows); if (S.li.some(s => sig(s.rows) === sg)) throw new Error('Deze export heb je al toegevoegd. Een nieuwere export van LinkedIn mag wel.');
    S.li.push({ id: 's' + Date.now(), date: todayIso(), file: file.name, rows });
    startTrialIfReady(); save();
    toast(`${plural(rows.length, 'connectie', 'connecties')} toegevoegd`);
  } catch (e) { U.err.li = e.message || 'Dit bestand konden we niet lezen.'; }
  render();
}
async function addInstagram(file) {
  U.err.ig = '';
  if (file.size > 60 * 1024 * 1024) { U.err.ig = 'Dit bestand is groter dan 60 MB. Vraag alleen Volgers en volgend aan.'; return render(); }
  try {
    const f = await readFile(file);
    let text = f.text;
    if (f.isZip) { text = await zipEntry(f.buf, n => /followers_\d+\.json$/i.test(n)); if (!text) throw new Error('In deze zip staan geen volgers. Kies bij Instagram Volgers en volgend, en het formaat JSON.'); }
    let data; try { data = JSON.parse(text); } catch (e) { throw new Error('Dit is geen JSON-bestand van Instagram. Kies bij het aanvragen het formaat JSON.'); }
    const rows = []; const seen = new Set();
    const walk = o => { if (Array.isArray(o)) return o.forEach(walk); if (o && typeof o === 'object') { if (Array.isArray(o.string_list_data)) o.string_list_data.forEach(s => { const v = (s.value || (s.href || '').split('/').filter(Boolean).pop() || o.title || '').trim().replace(/^_u\//, ''); if (v && !seen.has(v)) { seen.add(v); rows.push([v, s.timestamp ? new Date(s.timestamp * 1000).toISOString().slice(0, 10) : '']); } }); else Object.values(o).forEach(walk); } };
    walk(data);
    if (!rows.length) throw new Error('In dit bestand vonden we geen volgers.');
    S.meta.followers = { file: file.name, date: todayIso(), rows }; save();
    toast(`${plural(rows.length, 'volger', 'volgers')} toegevoegd`);
  } catch (e) { U.err.ig = e.message || 'Dit bestand konden we niet lezen.'; }
  render();
}
async function addCustomers(file) {
  U.err.cust = '';
  if (file.size > 25 * 1024 * 1024) { U.err.cust = 'Dit bestand is groter dan 25 MB.'; return render(); }
  try {
    if (/\.xlsx?$/i.test(file.name)) throw new Error('Excel lezen kan in dit concept nog niet. Kies in Excel: Bestand, Opslaan als, CSV.');
    const f = await readFile(file);
    if (f.isZip) throw new Error('Dit is een zip of een Excel-bestand. Sla het op als CSV.');
    const rows = parseCSV(f.text);
    if (rows.length < 2) throw new Error('In dit bestand staan geen rijen.');
    const headers = rows[0].map(h => h.trim());
    const lh = headers.map(h => h.toLowerCase());
    const find = re => lh.findIndex(h => re.test(h));
    const company = find(/bedrijf|company|organi[sz]ati|account|firma|relatie|klantnaam/);
    let contact = lh.findIndex((h, i) => i !== company && /contact|naam|name|persoon/.test(h) && !/bedrijf|company/.test(h));
    U.custDraft = { file: file.name, headers, rows: rows.slice(1, 5001), map: { company, contact, email: find(/mail/), status: find(/status|type|fase|stage|soort|lifecycle|categorie/) } };
  } catch (e) { U.err.cust = e.message || 'Dit bestand konden we niet lezen.'; }
  render();
}
function confirmMapping(quiet) {
  const d = U.custDraft; if (!d) return true;
  const m = d.map;
  if (m.company < 0) { U.err.map = 'Kies welke kolom de bedrijfsnaam is.'; U.mapEdit = true; if (!quiet) render(); return false; }
  const rows = d.rows.map(r => {
    const co = (r[m.company] || '').trim(); if (!co) return null;
    const em = m.email >= 0 ? (r[m.email] || '').trim() : '';
    const st = m.status >= 0 ? (r[m.status] || '').trim() : '';
    return [co, m.contact >= 0 ? (r[m.contact] || '').trim() : '', em.includes('@') ? em.split('@')[1].toLowerCase() : '', custClass(st), st];
  }).filter(Boolean);
  if (S.sample) clearSample();
  S.cust = { file: d.file, date: todayIso(), rows };
  U.custDraft = null; U.mapEdit = false; U.err.map = ''; startTrialIfReady(); save();
  toast(`${plural(rows.length, 'rij', 'rijen')} uit je klantenbestand toegevoegd`);
  if (!quiet) render();
  return true;
}
function loadSample() {
  const d = sampleData();
  d.snaps.forEach(s => { s.sample = true; }); if (d.cust) d.cust.sample = true;
  if (!realLi().length) S.li = d.snaps;
  if (!realCust()) S.cust = d.cust;
  S.sampleDream = d.dream; S.sample = true; save();
  toast('Voorbeeldgegevens geladen. Je eigen stappen blijven leeg.'); render();
}
function clearSample() {
  S.li = S.li.filter(s => !s.sample && !/voorbeeld/.test(s.file)); if (S.cust && (S.cust.sample || /voorbeeld/.test(S.cust.file))) S.cust = null;
  S.sampleDream = null; S.sample = false;
}
/* echte gegevens van de gebruiker; voorbeeldgegevens tellen nooit mee voor de start of de proef */
const realLi = () => S.li.filter(s => !s.sample);
const realCust = () => (S.cust && !S.cust.sample ? S.cust : null);

/* ------------------------------------------------------------------ acties */
function stepNext(n, skip) {
  const id = STEPS[n - 1].id; U.err = {}; U.ret = null;
  if (!skip && !commitPending(id)) return render();
  if (skip) S.skipped[id] = true; else delete S.skipped[id];
  save();
  go(n < STEPS.length ? 'start-' + (n + 1) : 'klaar');
}
function goRet(n) {
  const id = STEPS[n - 1].id; U.err = {};
  if (!commitPending(id)) return render();
  const to = U.ret || 'vandaag'; U.ret = null; save(); go(to);
}
function finish() { S.finished = true; S.parked = false; save(); go('vandaag'); toast('Welkom. Je overzicht staat klaar.'); }
function verifySite() {
  U.checking = true; render();
  setTimeout(() => { U.checking = false; S.site.verified = true; S.site.verifiedAt = new Date().toISOString(); startTrialIfReady(); save(); render(); toast('We zien je site'); }, 1400);
}
function demoAccount() {
  S = blank();
  S.account = { name: 'Jan de Vries', company: 'Vos Advies', email: 'jan@vosadvies.nl', website: 'vosadvies.nl' };
  S.plan = 'growth'; S.done.account = true; S.done.plan = true; S.mail.rhythm = 'Elke werkdag';
  U.draft = null; U.tm = null; U.dreamDraft = ''; U.custDraft = null; U.planPick = null; U.ret = null;
  save(); toast('Voorbeeldaccount gemaakt: Jan de Vries, Vos Advies');
}
function addDreams(quiet) {
  const v = U.dreamDraft || ''; const parts = v.split(/[\n,;]+/).map(x => x.trim()).filter(Boolean);
  let n = 0;
  for (const p of parts) if (!S.dream.some(d => d.toLowerCase() === p.toLowerCase()) && S.dream.length < 20) { S.dream.push(p); n++; }
  U.dreamDraft = ''; save();
  if (!quiet) { render(); const el = $('#f-dream'); if (el) el.focus(); if (n) toast(n === 1 ? `${parts[0]} toegevoegd` : `${n} droomklanten toegevoegd`); }
}
function addTeam(quiet) {
  const d = U.tm || {}; const name = (d.name || '').trim(), email = (d.email || '').trim();
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { U.err.tm = !name ? 'Vul een naam in.' : 'Vul een geldig mailadres in, bijvoorbeeld naam@jouwbedrijf.nl.'; if (!quiet) render(); return false; }
  U.err.tm = ''; S.team.push({ name, email, role: S.plan === 'free' ? 'Netwerklid' : (d.role || 'Netwerklid') });
  U.tm = { name: '', email: '', role: d.role || 'Netwerklid' }; save();
  toast(`${name} staat klaar om uit te nodigen`);
  if (!quiet) { render(); const el = $('#f-tm-name'); if (el) el.focus(); }
  return true;
}
function del(id) {
  if (id === 'all') { try { localStorage.removeItem(KEY); } catch (e) { /* niets */ } S = blank(); U.confirm = null; U.draft = null; toast('Alles gewist'); return go('aanmelden'); }
  if (id === 'free') { U.confirm = null; setPlan('free'); save(); toast('Je zit nu op Free. Je netwerk blijft.'); return render(); }
  if (id.startsWith('tm:')) { const m = S.team[+id.slice(3)]; S.team.splice(+id.slice(3), 1); U.confirm = null; save(); toast(m ? `${m.name} verwijderd` : 'Verwijderd'); return render(); }
  if (id === 'partner') { S.partner = null; U.confirm = null; U.partnerDemo = false; save(); toast('Je bent gestopt. Lopende commissies worden nog afgerekend.'); return render(); }
  if (id === 'ref-end') { S.referral.ended = todayIso(); S.accessLog.push({ at: todayIso(), what: `partner ${S.referral.code}: begeleidt niet meer, volgens jou` }); U.confirm = null; save(); toast('Vastgelegd. Je abonnement verandert niet.'); return render(); }
  if (id.startsWith('ag:')) { const a = S.agencyAccess[+id.slice(3)]; S.agencyAccess.splice(+id.slice(3), 1); if (a) S.accessLog.push({ at: todayIso(), what: `toegang van ${a.email} ingetrokken` }); U.confirm = null; save(); toast('Toegang ingetrokken'); return render(); }
  if (id === 'meta') { S.meta.connected = false; S.meta.at = null; U.confirm = null; save(); toast('Ontkoppeld van Meta'); return render(); }
  if (id === 'ig') { S.meta.followers = null; U.confirm = null; save(); toast('Volgers verwijderd'); return render(); }
  if (id === 'sample') { clearSample(); }
  else if (id === 'cust') { S.cust = null; if (S.crm === 'geen') S.crm = ''; }
  else if (id.startsWith('li:')) { S.li = S.li.filter(s => s.id !== id.slice(3)); }
  S.sample = S.li.some(s => s.sample) || !!(S.cust && S.cust.sample);
  U.confirm = null; save(); toast('Verwijderd'); render();
}
/* na een keuze: laat zien wat erbij kwam, als dat buiten beeld valt */
function revealPane() {
  const p = $('#pane'); if (!p) return;
  const r = p.getBoundingClientRect();
  if (r.top > innerHeight - 200) window.scrollBy({ top: r.top - (innerHeight - 280), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-act]'); if (!t) return;
  const a = t.dataset.act, v = t.dataset.v;
  const n = curStep();
  switch (a) {
    case 'step': U.err = {}; return go('start-' + v);
    case 'edit': U.err = {}; U.ret = t.dataset.ret || null; return go('start-' + v);
    case 'partner-pick': U.partnerPick = v; return render();
    case 'partner-terms': U.partnerTerms = !U.partnerTerms; U.err.partner = ''; return render();
    case 'partner-join': {
      const co = ($('#f-p-co') || {}).value || ''; if (!co.trim()) { U.err.partner = 'Vul de naam van je bedrijf in.'; return render(); }
      if (!U.partnerTerms) { U.err.partner = 'Ga eerst akkoord met de partnervoorwaarden.'; return render(); }
      U.err.partner = ''; S.partner = { type: U.partnerPick || U.pendingPartner || 'agency', code: partnerCode(), since: todayIso(), invites: [] }; save();
      toast(S.partner.type === 'agency' ? 'Welkom als partner' : 'Welkom als verwijzer'); return render();
    }
    case 'p-demo': U.partnerDemo = !U.partnerDemo; return render();
    case 'p-choice': { const [i, o] = v.split(':'); U.pchoice = U.pchoice || {}; U.pchoice[i] = o; toast(o === 'Korting' ? 'Je deel gaat als korting naar deze klant' : 'Je ontvangt de commissie zelf'); return render(); }
    case 'inv-send': {
      const d = U.inv || {}; const name = (d.name || '').trim(), email = (d.email || '').trim();
      if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { U.err.inv = 'Vul een naam en een geldig mailadres in.'; return render(); }
      U.err.inv = ''; S.partner.invites = S.partner.invites || []; S.partner.invites.push({ name, email, at: todayIso() }); U.inv = {}; save();
      const body = `Hoi ${firstName(name)},\n\nMet ${BRAND} zie je bij welke bedrijven je al iemand kent: uit je LinkedIn, je klanten en je website. Via deze link probeer je Growth ${PARTNER.clientTrialDays} dagen gratis:\n\n${refLink(S.partner.code)}\n\nGroet,\n${S.account ? S.account.name : ''}`;
      location.href = `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent('Je netwerk zit vol kansen')}&body=${encodeURIComponent(body)}`;
      return render();
    }
    case 'ag-scope': U.ag = U.ag || { email: '', scope: 'start' }; U.ag.scope = v; return render();
    case 'ag-add': {
      const d = U.ag || { email: '', scope: 'start' }; const email = (d.email || '').trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { U.err.ag = 'Vul een geldig mailadres in.'; return render(); }
      U.err.ag = ''; S.agencyAccess.push({ email, scope: d.scope || 'start', since: todayIso() }); S.accessLog.push({ at: todayIso(), what: `${email} kreeg toegang (${d.scope === 'kansen' ? 'ook kansen' : 'start en bronnen'})` });
      U.ag = { email: '', scope: 'start' }; save(); toast('Toegang gegeven. Je kunt die altijd intrekken.'); return render();
    }
    case 'meta-connect': S.meta.connected = true; S.meta.at = todayIso(); startTrialIfReady(); save(); toast('Gekoppeld met Meta (nagebootst)'); return render();
    case 'ai-linked': S.aiLinked = !S.aiLinked; save(); return render();
    case 'cust-via': if (S.custVia !== v) { S.custVia = v; save(); render(); revealPane(); } return;
    case 'cust-ai-sent': S.custAiSent = !S.custAiSent; save(); return render();
    case 'li-later': if (S.liRequested) toast('Prima. Zodra LinkedIn mailt, herinneren we je eraan.'); return stepNext(n, !S.liRequested);
    case 'resume': U.err = {}; U.ret = null; S.parked = false; save(); return go('start-' + v);
    case 'next': return stepNext(n, false);
    case 'skip': return stepNext(n, true);
    case 'ret': return goRet(n);
    case 'back': U.err = {}; return go('start-' + (n - 1));
    case 'finish': return finish();
    case 'later': if (!S.finished) { S.parked = true; save(); } return go('vandaag');
    case 'edit-derived': U.editDerived = true; render(); { const el = $('#f-company'); if (el) el.focus(); } return;
    case 'plan-pick': U.planPick = v; return render();
    case 'plan-go': { const p = U.planPick || S.plan || 'growth'; setPlan(p); U.planPick = null; save(); return go('start-3'); }
    case 'plan': setPlan(v); save(); toast(v === 'free' ? 'Free: 1 kans per week. Je netwerk blijft.' : `Growth: ${trialDays()} dagen gratis, zonder betaalkaart`); return render();
    case 'who': if (S.site.who !== v) { S.site.who = v; S.site.mode = v === 'own' ? 'own' : 'script'; save(); render(); revealPane(); } return;
    case 'platform': if (S.site.platform !== v) { S.site.platform = v; save(); render(); revealPane(); } return;
    case 'tool': S.site.tool = v; save(); render(); if (v === 'Iets anders') { const el = $('#f-tool-other'); if (el && !el.value) el.focus(); } return;
    case 'sent': S.site.builderSent = !S.site.builderSent; startTrialIfReady(); save(); return render();
    case 'li-req': S.liRequested = S.liRequested ? null : todayIso(); save(); if (S.liRequested) toast('Genoteerd. Ga gerust verder; de zip sleep je straks hierheen.'); return render();
    case 'crm': if (S.crm !== v) { S.crm = v; if (aiOn() && AI_CRMS.includes(v) && !S.custVia) S.custVia = 'ai'; save(); render(); revealPane(); } return;
    case 'map-edit': U.mapEdit = true; return render();
    case 'map-back': U.mapEdit = false; U.err.map = ''; return render();
    case 'map-ok': return confirmMapping();
    case 'map-cancel': U.custDraft = null; U.mapEdit = false; U.err.map = ''; render(); { const el = $('#f-cust'); if (el) el.click(); } return;
    case 'sugg': if (!S.dream.some(d => d.toLowerCase() === v.toLowerCase()) && S.dream.length < 20) S.dream.push(v); save(); return render();
    case 'verify': return verifySite();
    case 'design': U.design = !U.design; return render();
    case 'jump': U.design = false; U.ret = null; if (v === 'aanmelden') { U.forceSignup = true; U.draft = null; } else if (!S.account) demoAccount(); return go(v);
    case 'demo': demoAccount(); U.design = false; return go('start-2');
    case 'reset': try { localStorage.removeItem(KEY); } catch (e) { /* niets */ } S = blank(); U.design = false; U.custDraft = null; U.err = {}; U.draft = null; U.tm = null; U.dreamDraft = ''; U.planPick = null; U.ret = null; return go('aanmelden');
    case 'sample': U.design = false; if (!S.account) demoAccount(); return loadSample();
    case 'mkcrit': { const txt = S.icp.text.trim(); if (txt.length < 20) { U.err.icp = 'Schrijf iets meer: wie, waar, hoe groot, en wat ze nodig hebben.'; return render(); } U.err.icp = ''; S.icp.crit = mergeCrit(makeCrit(txt)); S.icp.critFrom = txt; save(); return render(); }
    case 'crit-clear': S.icp.crit = []; S.icp.critFrom = S.icp.text.trim(); save(); return render();
    case 'icp-sample': S.icp.text = sampleData().icp; save(); render(); { const el = $('#f-icp'); if (el) el.focus(); } return;
    case 'crit': S.icp.crit[+v].on = !S.icp.crit[+v].on; save(); return render();
    case 'dream': return addDreams();
    case 'undream': S.dream.splice(+v, 1); save(); render(); { const el = $('#f-dream'); if (el) el.focus({ preventScroll: true }); } return;
    case 'copy': return copyText(v);
    case 'rhythm': S.mail.rhythm = v; save(); return render();
    case 'tm-role': U.tm = U.tm || {}; U.tm.role = v; return render();
    case 'tm-setrole': { const [i, r] = v.split(':'); if (S.team[+i]) { S.team[+i].role = r; delete S.team[+i].prevRole; save(); } return render(); }
    case 'addtm': return addTeam();
    case 'untm': { const m = S.team[+v]; S.team.splice(+v, 1); save(); render(); if (m) toast(`${m.name} verwijderd`); return; }
    case 'ai': S.ai = v; if (aiOn() && AI_CRMS.includes(S.crm) && !S.custVia) S.custVia = 'ai'; save(); render(); revealPane(); return;
    case 'sel': U.sel = v; return render();
    case 'fb': S.fb[U.sel] = S.fb[U.sel] === v ? undefined : v; save(); if (S.fb[U.sel]) toast(`Vastgelegd: ${v.toLowerCase()}. Zo leert het systeem wat bij jou werkt.`); return render();
    case 'call': return toast('In het echt bel je zelf. Wij bellen nooit namens jou.');
    case 'mailp': return toast('Je eigen mailprogramma opent. Wij versturen niets.');
    case 'tender': return toast('Opent de aanbesteding op TenderNed');
    case 'allins': U.allIns = true; return render();
    case 'co': U.open[v] = !U.open[v]; return render();
    case 'mem': U.mem = v; render(); { const el = $('.mres'); if (el) el.scrollIntoView({ block: 'nearest' }); } return;
    case 'ask-del': U.confirm = v; return render();
    case 'nodel': U.confirm = null; return render();
    case 'del': return del(v);
    case 'pause': S.mail.paused = !S.mail.paused; save(); toast(S.mail.paused ? (S.plan === 'free' ? 'Afgemeld. Mail en zoeken staan stil; je netwerk blijft.' : 'Afgemeld voor de mail. Je abonnement loopt door.') : 'De kansenmail staat weer aan'); return render();
    case 'pay': return toast('Betalen komt bij de livegang. In dit concept verandert er niets.');
  }
});
document.addEventListener('submit', e => {
  const f = e.target.closest('[data-form]'); if (!f) return;
  e.preventDefault();
  const k = f.dataset.form;
  if (k === 'signup') {
    const a = readSignup(); if (!a) { render(); const el = $('.err'); const fld = el && el.parentElement.querySelector('input'); if (fld) fld.focus(); return; }
    const fresh = !S.account || S.account.email !== a.email;
    if (fresh) { const keep = S.account ? null : S; S = keep || blank(); }
    S.account = a; S.done.account = true; U.draft = null; U.editDerived = false; U.forceSignup = false;
    if (U.pendingRef && !S.referral) S.referral = { code: U.pendingRef, at: todayIso() };
    if (U.pendingPlan === 'growth' || U.pendingPlan === 'free') U.planPick = U.pendingPlan;
    save(); history.replaceState(null, '', U.pendingPartner && !S.plan ? '#partners' : '#start-2'); return render();
  }
  if (k === 'login') {
    const v = $('#f-login').value.trim();
    if (S.account && v.toLowerCase() === S.account.email.toLowerCase()) { toast('Welkom terug'); return go(S.finished || S.parked ? 'vandaag' : nextOpen()); }
    return toast('Inloggen per mail komt bij de livegang. In dit concept staat je account alleen in de browser waarin je het maakte.');
  }
  if (k === 'mem') { U.mem = ($('#f-mem') || {}).value || ''; return render(); }
  if (k === 'account') { const a = readAccount(); if (!a) return render(); S.account = a; save(); toast('Bewaard'); return render(); }
});
document.addEventListener('change', e => {
  const t = e.target;
  if (t.id === 'f-li' && t.files && t.files[0]) { addLinkedIn(t.files[0]); t.value = ''; }
  if (t.id === 'f-cust' && t.files && t.files[0]) { addCustomers(t.files[0]); t.value = ''; }
  if (t.id === 'f-ig' && t.files && t.files[0]) { addInstagram(t.files[0]); t.value = ''; }
  if (t.id === 'f-time') { S.mail.time = t.value; save(); toast('Je mail komt om ' + t.value); }
  if (t.id && t.id.startsWith('map-') && U.custDraft) { U.custDraft.map[t.id.slice(4)] = +t.value; }
});
/* typen bewaart meteen; er volgt geen volledige nieuwe weergave, dus een klik op een knop ernaast komt altijd aan */
document.addEventListener('input', e => {
  const id = e.target.id;
  const sid = { 'f-name': 'name', 'f-email': 'email', 'f-company': 'company', 'f-site': 'site' }[id];
  if (sid && $('[data-form=signup]')) {
    U.draft = U.draft || {}; U.draft[sid] = e.target.value;
    if (sid === 'email' && !U.editDerived) {
      const dz = $('#derived'); const freeMail = FREE_MAIL.test(e.target.value);
      if (!freeMail) { U.draft.company = ''; U.draft.site = ''; }
      if (dz) dz.innerHTML = derivedHtml();
    }
    return;
  }
  if (id === 'f-builder') { S.site.builder = e.target.value.trim(); save(); const m = $('#mailto'); if (m) m.href = builderHref(); return; }
  if (id === 'f-tool-other') { S.site.toolOther = e.target.value; save(); refreshChrome(); return; }
  if (id === 'f-icp') { S.icp.text = e.target.value; U.err.icp = ''; save(); const sb = $('[data-act=icp-sample]'); if (sb) sb.hidden = !!e.target.value.trim(); refreshChrome(); return; }
  if (id === 'f-dream') { U.dreamDraft = e.target.value; save(); refreshChrome(); return; }
  if (id === 'f-tm-name' || id === 'f-tm-email') { U.tm = U.tm || { name: '', email: '', role: 'Netwerklid' }; U.tm[id === 'f-tm-name' ? 'name' : 'email'] = e.target.value; U.err.tm = ''; save(); refreshChrome(); return; }
  if (id === 'f-p-co' || id === 'f-p-site') { U.pdraft = U.pdraft || {}; U.pdraft[id === 'f-p-co' ? 'co' : 'site'] = e.target.value; return; }
  if (id === 'f-inv-name' || id === 'f-inv-email') { U.inv = U.inv || {}; U.inv[id === 'f-inv-name' ? 'name' : 'email'] = e.target.value; U.err.inv = ''; return; }
  if (id === 'f-ag-email') { U.ag = U.ag || { email: '', scope: 'start' }; U.ag.email = e.target.value; U.err.ag = ''; return; }
  if (id === 'f-q') { U.q = e.target.value; render(); }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.id === 'f-dream') { e.preventDefault(); addDreams(); }
  if (e.key === 'Enter' && (e.target.id === 'f-tm-name' || e.target.id === 'f-tm-email')) { e.preventDefault(); addTeam(); }
  /* pijltjes in een keuzegroep, zoals bij gewone keuzerondjes */
  const r = e.target.closest && e.target.closest('[role=radio]');
  if (r && ['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft'].includes(e.key)) {
    const g = r.closest('[role=radiogroup]'); if (!g) return;
    const all = [...g.querySelectorAll('[role=radio]')]; const i = all.indexOf(r);
    const nx = all[(i + (e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : -1) + all.length) % all.length];
    e.preventDefault(); nx.focus(); nx.click();
  }
});
['dragenter', 'dragover'].forEach(ev => document.addEventListener(ev, e => { const z = e.target.closest && e.target.closest('[data-drop]'); if (z) { e.preventDefault(); z.classList.add('over'); } }));
['dragleave', 'drop'].forEach(ev => document.addEventListener(ev, e => { const z = e.target.closest && e.target.closest('[data-drop]'); if (z) z.classList.remove('over'); }));
document.addEventListener('drop', e => {
  const z = e.target.closest && e.target.closest('[data-drop]'); if (!z) return;
  e.preventDefault(); const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (!f) return;
  if (z.dataset.drop === 'li') addLinkedIn(f); else if (z.dataset.drop === 'ig') addInstagram(f); else addCustomers(f);
});
window.addEventListener('hashchange', () => {
  U.confirm = null; U.design = false;
  const h = location.hash.slice(1);
  if (!h.startsWith('start-')) U.ret = null;
  if (h !== 'aanmelden') U.forceSignup = false;
  render(); window.scrollTo(0, 0);
});

/* ------------------------------------------------------------------ start */
(function boot() {
  const p = new URLSearchParams(location.search);
  const pl = p.get('plan'); if (pl && PLANS[pl]) U.pendingPlan = pl;
  const ref = (p.get('ref') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 20); if (ref) U.pendingRef = ref;
  const pk = p.get('partner'); if (pk === 'agency' || pk === 'affiliate') U.pendingPartner = pk;
  if (/\/(signup|aanmelden)\/?$/.test(location.pathname) && !location.hash) history.replaceState(null, '', '#aanmelden');
  if (/\/(login|inloggen)\/?$/.test(location.pathname) && !location.hash) history.replaceState(null, '', '#inloggen');
  render();
})();
})();
